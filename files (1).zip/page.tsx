/**
 * app/dashboard/assets/page.tsx  (updated for universe)
 *
 * Asset Screener with:
 *  - Search box → /api/assets/search (trigram on full universe)
 *  - Browse mode → /api/assets (paginated, filtered by type/signal)
 *  - Real prices + sparklines where available
 *  - "Add to portfolio" button per row
 */

'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import styles from './assets.module.css'

// ─── Types ───────────────────────────────────────────────────────────────────

interface SparkBar { t: number; c: number }

interface Asset {
  ticker: string
  name: string
  asset_type: string
  sector: string | null
  market_cap_tier: string | null
  price: number | null
  change: number | null
  change_pct: number | null
  sparkline_bars: SparkBar[]
  signal: 'buy' | 'watch' | 'hold' | 'avoid' | null
  signal_score: number | null
  has_real_price: boolean
  is_exact_match?: boolean
}

type FilterType = 'all' | 'stock' | 'etf' | 'crypto'
type FilterSignal = 'all' | 'buy' | 'watch' | 'hold' | 'avoid'

// ─── Sub-components ───────────────────────────────────────────────────────────

function Sparkline({ bars, positive }: { bars: SparkBar[]; positive: boolean }) {
  if (!bars?.length || bars.length < 2) return <span className={styles.dash}>—</span>
  const W = 72; const H = 26
  const prices = bars.map(b => b.c)
  const min = Math.min(...prices); const max = Math.max(...prices)
  const range = max - min || 1
  const pts = prices.map((p, i) =>
    `${((i / (prices.length - 1)) * W).toFixed(1)},${(H - ((p - min) / range) * H).toFixed(1)}`
  ).join(' ')
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
      <polyline points={pts} fill="none" stroke={positive ? '#1D9E75' : '#E24B4A'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SignalBadge({ signal }: { signal: Asset['signal'] }) {
  if (!signal) return null
  const map = { buy: styles.sigBuy, watch: styles.sigWatch, hold: styles.sigHold, avoid: styles.sigAvoid }
  return <span className={`${styles.sigBadge} ${map[signal]}`}>{signal.toUpperCase()}</span>
}

function TierDot({ tier }: { tier: string | null }) {
  if (!tier) return null
  const map: Record<string, string> = { mega: '#c8a96e', large: '#7ab4e8', mid: 'rgba(15,28,46,0.3)' }
  return <span className={styles.tierDot} style={{ background: map[tier] ?? 'rgba(15,28,46,0.2)' }} title={`${tier} cap`} />
}

// ─── Add to portfolio inline ──────────────────────────────────────────────────

function AddToPortfolioBtn({ ticker }: { ticker: string }) {
  const [state, setState] = useState<'idle' | 'adding' | 'done' | 'err'>('idle')

  async function add() {
    setState('adding')
    try {
      const res = await fetch('/api/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticker }),
      })
      setState(res.ok ? 'done' : 'err')
      if (res.ok) setTimeout(() => setState('idle'), 3000)
    } catch {
      setState('err')
    }
  }

  if (state === 'done') return <span className={styles.addedTag}>✓ Added</span>
  if (state === 'err')  return <span className={styles.addErrTag}>Failed</span>
  return (
    <button className={styles.addBtn} onClick={add} disabled={state === 'adding'}>
      {state === 'adding' ? '…' : '+ Portfolio'}
    </button>
  )
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function AssetsPage() {
  const [mode, setMode] = useState<'browse' | 'search'>('browse')
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Browse filters
  const [typeFilter, setTypeFilter] = useState<FilterType>('all')
  const [signalFilter, setSignalFilter] = useState<FilterSignal>('all')
  const [page, setPage] = useState(0)
  const PAGE_SIZE = 50

  // Search
  const [searchQ, setSearchQ] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Meta
  const [totalWithPrices, setTotalWithPrices] = useState(0)
  const [lastSync, setLastSync] = useState<string | null>(null)
  const [universeCount, setUniverseCount] = useState(0)

  // ── Fetch browse data ──────────────────────────────────────────────────────

  const fetchBrowse = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const p = new URLSearchParams({
        sort: 'signal_score',
        limit: String(PAGE_SIZE),
        offset: String(page * PAGE_SIZE),
      })
      if (typeFilter !== 'all') p.set('type', typeFilter)
      if (signalFilter !== 'all') p.set('signal', signalFilter)

      const res = await fetch(`/api/assets?${p}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setAssets(data.assets ?? [])
      setTotalWithPrices(data.meta?.with_real_prices ?? 0)
      setLastSync(data.meta?.last_sync ?? null)
      setUniverseCount(data.meta?.universe_total ?? 0)
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }, [typeFilter, signalFilter, page])

  // ── Fetch search results ───────────────────────────────────────────────────

  const fetchSearch = useCallback(async (q: string) => {
    if (!q.trim()) { setMode('browse'); return }
    setMode('search'); setLoading(true); setError(null)
    try {
      const p = new URLSearchParams({ q, fetch: 'true', limit: '30' })
      if (typeFilter !== 'all') p.set('type', typeFilter)
      const res = await fetch(`/api/assets/search?${p}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setAssets(data.assets ?? [])
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }, [typeFilter])

  // Debounce search input
  function onSearchChange(val: string) {
    setSearchInput(val)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    if (!val.trim()) { setSearchQ(''); setMode('browse'); return }
    searchTimer.current = setTimeout(() => {
      setSearchQ(val)
      fetchSearch(val)
    }, 350)
  }

  function clearSearch() {
    setSearchInput(''); setSearchQ(''); setMode('browse')
  }

  useEffect(() => {
    if (mode === 'browse') fetchBrowse()
  }, [fetchBrowse, mode])

  // ── Formatters ────────────────────────────────────────────────────────────

  const fmtPrice = (n: number | null) =>
    n == null ? '—' : `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

  const fmtChg = (n: number | null) =>
    n == null ? '—' : `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`

  const fmtVol = (v: number | null) => {
    if (v == null) return '—'
    if (v >= 1e9) return `${(v / 1e9).toFixed(1)}B`
    if (v >= 1e6) return `${(v / 1e6).toFixed(1)}M`
    if (v >= 1e3) return `${(v / 1e3).toFixed(0)}K`
    return String(v)
  }

  return (
    <div className={styles.page}>

      {/* ── Header ── */}
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Asset Screener</h1>
          <p className={styles.sub}>
            {universeCount > 0
              ? `${universeCount.toLocaleString()} assets in universe · ${totalWithPrices} with live prices`
              : totalWithPrices > 0
                ? `${totalWithPrices} assets with live prices · synced ${lastSync ? new Date(lastSync).toLocaleString() : 'today'}`
                : 'Prices sync daily at 8am UTC via Polygon.io'}
          </p>
        </div>
      </div>

      {/* ── Search + filters ── */}
      <div className={styles.controls}>
        <div className={styles.searchWrap}>
          <svg className={styles.searchIcon} width="14" height="14" viewBox="0 0 14 14" fill="none">
            <circle cx="6" cy="6" r="4.5" stroke="currentColor" strokeWidth="1.4"/>
            <path d="M9.5 9.5L12.5 12.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
          </svg>
          <input
            className={styles.searchInput}
            placeholder="Search ticker or company name…"
            value={searchInput}
            onChange={e => onSearchChange(e.target.value)}
          />
          {searchInput && (
            <button className={styles.searchClear} onClick={clearSearch}>×</button>
          )}
        </div>

        <div className={styles.filterBar}>
          <div className={styles.filterGroup}>
            {(['all', 'stock', 'etf', 'crypto'] as FilterType[]).map(t => (
              <button
                key={t}
                className={`${styles.filterBtn} ${typeFilter === t ? styles.filterBtnActive : ''}`}
                onClick={() => { setTypeFilter(t); if (mode === 'browse') setPage(0) }}
              >
                {t === 'all' ? 'All' : t.toUpperCase()}
              </button>
            ))}
          </div>

          {mode === 'browse' && (
            <div className={styles.filterGroup}>
              {(['all', 'buy', 'watch', 'hold', 'avoid'] as FilterSignal[]).map(s => (
                <button
                  key={s}
                  className={`${styles.filterBtn} ${signalFilter === s ? styles.filterBtnActive : ''}`}
                  onClick={() => { setSignalFilter(s); setPage(0) }}
                >
                  {s === 'all' ? 'All signals' : s.toUpperCase()}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Search mode label ── */}
      {mode === 'search' && searchQ && (
        <div className={styles.searchLabel}>
          Search results for <strong>"{searchQ}"</strong>
          <button className={styles.backBtn} onClick={clearSearch}>← Browse all</button>
        </div>
      )}

      {/* ── States ── */}
      {loading && <div className={styles.loading}>Loading…</div>}
      {error && <div className={styles.error}>{error}</div>}

      {/* ── Table ── */}
      {!loading && !error && (
        <>
          <div className={styles.tableWrap}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Asset</th>
                  <th>Type</th>
                  <th className={styles.right}>Price</th>
                  <th className={styles.right}>Day</th>
                  <th>30d</th>
                  <th>Signal</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {assets.length === 0 && (
                  <tr>
                    <td colSpan={7} className={styles.empty}>
                      {mode === 'search' ? `No assets matching "${searchQ}"` : 'No assets match filters.'}
                    </td>
                  </tr>
                )}
                {assets.map(a => {
                  const pos = (a.change_pct ?? 0) >= 0
                  return (
                    <tr key={a.ticker}>
                      <td>
                        <div className={styles.assetCell}>
                          <div className={styles.assetTop}>
                            <span className={styles.ticker}>{a.ticker}</span>
                            <TierDot tier={a.market_cap_tier} />
                          </div>
                          <span className={styles.name}>{a.name}</span>
                        </div>
                      </td>
                      <td>
                        <span className={`${styles.typeBadge} ${styles[`type_${a.asset_type}`]}`}>
                          {a.asset_type}
                        </span>
                      </td>
                      <td className={styles.right}>
                        <span className={a.has_real_price ? styles.price : styles.noPrice}>
                          {fmtPrice(a.price)}
                        </span>
                      </td>
                      <td className={styles.right}>
                        {a.change_pct != null ? (
                          <span className={pos ? styles.changeUp : styles.changeDown}>
                            {fmtChg(a.change_pct)}
                          </span>
                        ) : <span className={styles.noPrice}>—</span>}
                      </td>
                      <td>
                        <Sparkline bars={a.sparkline_bars} positive={pos} />
                      </td>
                      <td>
                        {a.signal
                          ? <SignalBadge signal={a.signal} />
                          : <span className={styles.noPrice}>—</span>
                        }
                      </td>
                      <td>
                        <AddToPortfolioBtn ticker={a.ticker} />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination (browse mode only) */}
          {mode === 'browse' && assets.length === PAGE_SIZE && (
            <div className={styles.pagination}>
              <button
                className={styles.pageBtn}
                disabled={page === 0}
                onClick={() => setPage(p => p - 1)}
              >
                ← Previous
              </button>
              <span className={styles.pageInfo}>Page {page + 1}</span>
              <button
                className={styles.pageBtn}
                onClick={() => setPage(p => p + 1)}
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
