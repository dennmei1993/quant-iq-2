/**
 * app/api/assets/search/route.ts
 *
 * GET /api/assets/search?q=nvda
 *
 * Two behaviours:
 *   1. Search the local universe (fast — Postgres trigram, <50ms)
 *      Returns matching assets with price data if available.
 *
 *   2. If a result has no price data yet (has_data = false / no signal row)
 *      AND the user passes ?fetch=true, triggers an on-demand Polygon fetch
 *      for that single ticker and returns the enriched result.
 *
 * Query params:
 *   q       : search string (ticker or company name), min 1 char
 *   type    : stock | etf | crypto | commodity (optional filter)
 *   fetch   : true → trigger on-demand Polygon fetch for results without prices
 *   limit   : max results (default 20, max 50)
 *
 * Auth: requires valid Supabase session cookie.
 *
 * Example calls:
 *   /api/assets/search?q=apple          → name search
 *   /api/assets/search?q=NVDA           → exact ticker match first
 *   /api/assets/search?q=NV&type=stock  → filtered
 *   /api/assets/search?q=HIMS&fetch=true → fetch price if not yet synced
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { fetchPricesForTickers, fetchSparklinesForTickers } from '@/lib/polygon'

// Signal derivation (keep in sync with ingest cron)
function deriveSignal(changePct: number): 'buy' | 'watch' | 'hold' | 'avoid' {
  if (changePct >= 2) return 'buy'
  if (changePct >= 0.5) return 'watch'
  if (changePct >= -1) return 'hold'
  return 'avoid'
}

function deriveSignalScore(changePct: number): number {
  return Math.round(Math.min(100, Math.max(0, 50 + changePct * 10)))
}

export async function GET(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const params = req.nextUrl.searchParams
  const q = params.get('q')?.trim() ?? ''
  const typeFilter = params.get('type')
  const shouldFetch = params.get('fetch') === 'true'
  const limit = Math.min(50, parseInt(params.get('limit') ?? '20', 10))

  if (q.length === 0) {
    return NextResponse.json({ assets: [] })
  }

  // ── 1. Search the assets universe ─────────────────────────────────────────
  //
  // Strategy: try exact ticker match first, then trigram similarity on
  // both ticker and name. Union them, deduplicate, rank by relevance.
  //
  // Postgres query:
  //   - ticker ILIKE 'Q%' for prefix matching (very fast on btree)
  //   - OR name ILIKE '%apple%' for name substring (uses trgm GIN index)
  //   - ORDER BY: exact ticker match first, then similarity score

  const qUpper = q.toUpperCase()

  let query = supabase
    .from('assets')
    .select('ticker, name, asset_type, sector, market_cap_tier, bootstrap_priority')
    .eq('is_active', true)
    .or(`ticker.ilike.${qUpper}%,name.ilike.%${q}%`)
    .order('bootstrap_priority', { ascending: true, nullsFirst: false })
    .limit(limit)

  if (typeFilter && ['stock', 'etf', 'crypto', 'commodity'].includes(typeFilter)) {
    query = query.eq('asset_type', typeFilter)
  }

  const { data: assets, error: searchErr } = await query

  if (searchErr) {
    return NextResponse.json({ error: searchErr.message }, { status: 500 })
  }

  if (!assets?.length) {
    return NextResponse.json({ assets: [], total: 0 })
  }

  // ── 2. Load existing price data for found tickers ─────────────────────────

  const tickers = assets.map(a => a.ticker)

  const { data: signals } = await supabase
    .from('asset_signals')
    .select('ticker, price, change, change_pct, signal, signal_score, sparkline_bars, has_data, price_updated_at')
    .in('ticker', tickers)

  const signalMap = new Map<string, any>()
  for (const s of signals ?? []) {
    signalMap.set(s.ticker, s)
  }

  // ── 3. On-demand fetch for unpopulated tickers ────────────────────────────

  if (shouldFetch) {
    const toFetch = tickers.filter(t => {
      const sig = signalMap.get(t)
      return !sig || !sig.has_data
    })

    if (toFetch.length > 0 && toFetch.length <= 5) {
      // Only on-demand fetch if it's a small number (single ticker search)
      // Don't block on large result sets — cron handles those
      try {
        const prices = await fetchPricesForTickers(toFetch)
        const sparklines = await fetchSparklinesForTickers([...prices.keys()])

        const upsertRows = [...prices.keys()].map(t => {
          const p = prices.get(t)!
          const bars = sparklines.get(t) ?? []
          return {
            ticker: t,
            price: p.price,
            open: p.open,
            high: p.high,
            low: p.low,
            change: p.change,
            change_pct: p.change_pct,
            volume: p.volume,
            sparkline_bars: bars,
            signal: deriveSignal(p.change_pct),
            signal_score: deriveSignalScore(p.change_pct),
            price_updated_at: p.updated_at,
            updated_at: new Date().toISOString(),
            has_data: true,
          }
        })

        if (upsertRows.length > 0) {
          await supabase
            .from('asset_signals')
            .upsert(upsertRows, { onConflict: 'ticker' })

          // Update local signalMap with freshly fetched data
          for (const row of upsertRows) {
            signalMap.set(row.ticker, row)
          }
        }
      } catch (err) {
        // Non-fatal — return results without prices rather than 500
        console.error('[search] on-demand fetch failed:', err)
      }
    }
  }

  // ── 4. Merge + rank results ───────────────────────────────────────────────

  const results = assets
    .map(asset => {
      const sig = signalMap.get(asset.ticker)
      const isExactMatch = asset.ticker === qUpper

      return {
        ticker: asset.ticker,
        name: asset.name,
        asset_type: asset.asset_type,
        sector: asset.sector ?? null,
        market_cap_tier: asset.market_cap_tier ?? null,
        // Price data
        price: sig?.price ?? null,
        change: sig?.change ?? null,
        change_pct: sig?.change_pct ?? null,
        sparkline_bars: sig?.sparkline_bars ?? [],
        signal: sig?.signal ?? null,
        signal_score: sig?.signal_score ?? null,
        has_real_price: !!sig?.has_data,
        price_updated_at: sig?.price_updated_at ?? null,
        // Search relevance metadata
        is_exact_match: isExactMatch,
      }
    })
    // Sort: exact ticker match first, then by bootstrap_priority (most important assets)
    .sort((a, b) => {
      if (a.is_exact_match && !b.is_exact_match) return -1
      if (!a.is_exact_match && b.is_exact_match) return 1
      // Prefer assets with price data
      if (a.has_real_price && !b.has_real_price) return -1
      if (!a.has_real_price && b.has_real_price) return 1
      return 0
    })

  return NextResponse.json({
    assets: results,
    total: results.length,
    query: q,
  })
}
