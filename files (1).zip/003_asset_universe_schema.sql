-- ============================================================================
-- supabase/migrations/003_asset_universe_schema.sql
--
-- Schema changes to support the expanded asset universe:
--   1. Add market_cap_tier to assets
--   2. Add is_bootstrapped flag so cron knows which assets have been price-synced
--   3. Add search index (trigram) on ticker + name for fast /api/assets/search
--   4. Add bootstrap priority so cron processes top assets first
-- ============================================================================

-- ── 1. Extend assets table ───────────────────────────────────────────────────

ALTER TABLE assets
  ADD COLUMN IF NOT EXISTS market_cap_tier   text CHECK (market_cap_tier IN ('mega','large','mid','small')),
  ADD COLUMN IF NOT EXISTS is_active         boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS bootstrap_priority integer,  -- lower = fetch price sooner
  ADD COLUMN IF NOT EXISTS added_by          text DEFAULT 'seed'; -- 'seed' | 'user' | 'admin'

COMMENT ON COLUMN assets.market_cap_tier IS
  'mega = >$200B, large = $10B-$200B, mid = $2B-$10B, small = <$2B';

COMMENT ON COLUMN assets.bootstrap_priority IS
  'Lower number = higher priority for initial Polygon price bootstrapping. NULL = not yet assigned.';

-- ── 2. Set bootstrap priorities ──────────────────────────────────────────────
-- Top 100 S&P 500 stocks by approximate market cap get priority 1
-- Top 100 ETFs by AUM get priority 2
-- Top 20 cryptos get priority 3
-- Rest of S&P 500 gets priority 4

UPDATE assets SET bootstrap_priority = 1
WHERE ticker IN (
  'AAPL','MSFT','NVDA','GOOGL','AMZN','META','TSLA','BRK.B','LLY','JPM',
  'V','UNH','XOM','MA','JNJ','PG','AVGO','HD','ABBV','MRK',
  'CVX','COST','PEP','KO','ADBE','AMD','CSCO','WMT','TMO','CRM',
  'ACN','MCD','BAC','ORCL','NFLX','ABT','QCOM','NKE','DIS','TXN',
  'PM','WFC','DHR','INTU','VZ','CAT','GS','IBM','AMGN','SPGI',
  'GE','MS','RTX','T','HON','BLK','SCHW','NOW','PFE','BMY',
  'ISRG','GILD','AMAT','LOW','AXP','C','DE','CMCSA','PGR','MU',
  'ELV','REGN','VRTX','LRCX','KLAC','MDLZ','SLB','COP','CI','USB',
  'ETN','ADI','PNC','TFC','COF','NSC','UPS','FDX','LMT','NOC',
  'PYPL','UBER','SQ','COIN','PLTR','PANW','CRWD','DDOG','NET','SNOW'
);

UPDATE assets SET bootstrap_priority = 2
WHERE asset_type = 'etf'
AND ticker IN (
  'SPY','IVV','VOO','VTI','QQQ','IWM','GLD','AGG','BND','TLT',
  'VEA','VWO','EFA','EEM','XLK','XLF','XLV','XLC','XLY','XLP',
  'XLI','XLE','XLU','XLB','XLRE','VGT','SOXX','SMH','IAU','SLV',
  'ARKK','ARKG','TQQQ','SQQQ','HYG','LQD','IEF','ACWI','DIA','MDY',
  'VUG','VTV','MTUM','QUAL','USMV','VIG','DGRO','DVY','BOTZ','CLOU',
  'HACK','BUG','CIBR','IGV','ICLN','TAN','JETS','USO','TIP','PDBC',
  'XLK','QCLN','LIT','DRIV','KARS','FINX','IPAY','WCLD','AIQ','ROBO'
);

UPDATE assets SET bootstrap_priority = 3
WHERE asset_type = 'crypto';

UPDATE assets SET bootstrap_priority = 4
WHERE bootstrap_priority IS NULL;

-- ── 3. Search indexes ─────────────────────────────────────────────────────────

-- Enable pg_trgm extension for fuzzy ticker/name search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- GIN trigram index on ticker for fast ILIKE '%nvda%' queries
CREATE INDEX IF NOT EXISTS assets_ticker_trgm_idx
  ON assets USING GIN (ticker gin_trgm_ops);

-- GIN trigram index on name for 'apple' → 'Apple Inc' matching
CREATE INDEX IF NOT EXISTS assets_name_trgm_idx
  ON assets USING GIN (name gin_trgm_ops);

-- Simple btree on asset_type for type-filter queries
CREATE INDEX IF NOT EXISTS assets_type_idx ON assets (asset_type);

-- Btree on bootstrap_priority for cron ordering
CREATE INDEX IF NOT EXISTS assets_bootstrap_priority_idx ON assets (bootstrap_priority)
  WHERE bootstrap_priority IS NOT NULL;

-- ── 4. asset_signals — add a has_data flag for quick "has this been synced?" ──

ALTER TABLE asset_signals
  ADD COLUMN IF NOT EXISTS has_data boolean NOT NULL DEFAULT false;

-- Set has_data = true for any rows that already have a price
UPDATE asset_signals SET has_data = true WHERE price IS NOT NULL;

-- ── 5. RLS — assets table stays publicly readable by authenticated users ──────
-- (Already set in migration 001 — no change needed)
-- Confirm policy exists:
--   SELECT * FROM pg_policies WHERE tablename = 'assets';

-- ── Verify ────────────────────────────────────────────────────────────────────
-- After running, check:
--
-- SELECT asset_type, COUNT(*) FROM assets GROUP BY asset_type ORDER BY 2 DESC;
-- SELECT bootstrap_priority, COUNT(*) FROM assets GROUP BY bootstrap_priority ORDER BY 1;
-- SELECT * FROM pg_indexes WHERE tablename = 'assets';
