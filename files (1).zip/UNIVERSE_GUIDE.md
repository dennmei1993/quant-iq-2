# Quant IQ — Asset Universe Expansion Guide

## What was built

| Deliverable | File | Purpose |
|---|---|---|
| Schema migration | `supabase/migrations/003_asset_universe_schema.sql` | Adds `market_cap_tier`, `bootstrap_priority`, trigram search indexes |
| Asset universe seed | `supabase/seeds/003_asset_universe.sql` | ~573 assets: S&P 500 + top 100 ETFs + top 20 cryptos |
| Bootstrap cron | `src/app/api/cron/bootstrap-prices/route.ts` | One-time Polygon price fetch by priority tier |
| Search API | `src/app/api/assets/search/route.ts` | Trigram search across full universe + on-demand price fetch |
| Browse API | `src/app/api/assets/route.ts` | Paginated browse with universe total count |
| Screener UI | `src/app/dashboard/assets/page.tsx` | Search + browse + add to portfolio |
| Crypto map update | `src/lib/polygon_crypto_map_update.ts` | Updated CRYPTO_MAP for all 20 seeded cryptos |

---

## Deploy steps

### Step 1 — Run migrations in order

In Supabase SQL Editor, run in this exact order:

```sql
-- 1. Schema changes (adds columns + indexes)
-- Run: supabase/migrations/003_asset_universe_schema.sql

-- 2. Seed the universe (~573 assets)
-- Run: supabase/seeds/003_asset_universe.sql
```

Verify with:
```sql
SELECT asset_type, COUNT(*) FROM assets GROUP BY asset_type ORDER BY 2 DESC;
-- Expected:
-- stock  | 453
-- etf    | 100
-- crypto |  20
```

### Step 2 — Update CRYPTO_MAP in lib/polygon.ts

Replace the `CRYPTO_MAP` constant in `src/lib/polygon.ts` with the updated version
from `src/lib/polygon_crypto_map_update.ts`. This covers all 20 seeded cryptos.

### Step 3 — Deploy updated files

```
src/app/api/assets/route.ts          → REPLACE (pagination + universe count)
src/app/api/assets/search/route.ts   → NEW (trigram search)
src/app/api/cron/bootstrap-prices/route.ts → NEW
src/app/dashboard/assets/page.tsx    → REPLACE (search + universe UI)
src/app/dashboard/assets/assets.module.css → REPLACE
src/lib/polygon.ts                   → UPDATE CRYPTO_MAP section only
```

### Step 4 — Bootstrap prices in 4 batches

Run these curl commands in order, waiting for each to complete before the next.
Each takes ~65 seconds on Polygon free tier (5 req/min).

```bash
CRON_SECRET=your_secret
APP_URL=https://your-app.vercel.app

# Priority 1: Top 100 S&P 500 stocks (~100 tickers, ~5 batches)
curl -H "Authorization: Bearer $CRON_SECRET" \
  "$APP_URL/api/cron/bootstrap-prices?priority=1"

# Priority 2: Top ETFs (~70 tickers, ~4 batches)  
curl -H "Authorization: Bearer $CRON_SECRET" \
  "$APP_URL/api/cron/bootstrap-prices?priority=2"

# Priority 3: Crypto (20 tickers, 1 batch)
curl -H "Authorization: Bearer $CRON_SECRET" \
  "$APP_URL/api/cron/bootstrap-prices?priority=3"

# Priority 4: Rest of S&P 500 (~350 tickers, ~18 batches, ~4min)
# Run this overnight or in a Vercel Pro cron with higher timeout
curl -H "Authorization: Bearer $CRON_SECRET" \
  "$APP_URL/api/cron/bootstrap-prices?priority=4"
```

> **Vercel timeout:** Priority 1–3 each run in ~1–2 minutes, within the 5-min
> cron function limit. Priority 4 (~350 tickers) takes ~4 minutes — set
> `maxDuration: 300` in `vercel.json` for the bootstrap route.

### Step 5 — Verify the screener

Open `/dashboard/assets` and confirm:
- Universe count shows ~573 in the header
- Prices are visible for the top stocks/ETFs
- Search box finds "Apple" → AAPL with price
- Type filter works (STOCK / ETF / CRYPTO)
- "Add to portfolio" button works from the screener

---

## How the architecture works

```
assets table (~573 rows)              asset_signals table
┌─────────────────────────────┐       ┌──────────────────────────────────┐
│ ticker │ name   │ type │ ... │  1:1  │ ticker │ price │ sparkline │ ... │
│ AAPL   │ Apple  │stock │  1  │ ────► │ AAPL   │ 213.4 │ [...]     │ ✓   │
│ NVDA   │ NVIDIA │stock │  1  │ ────► │ NVDA   │ 875.2 │ [...]     │ ✓   │
│ HIMS   │ Hims   │stock │  4  │ ────► │ (none) │  —    │  —        │ ✗   │
└─────────────────────────────┘       └──────────────────────────────────┘
       bootstrap_priority ↑                  has_data: true/false ↑

When a user searches "HIMS":
  1. assets table → found (ticker, name, type)
  2. asset_signals → no row
  3. ?fetch=true → fetchPricesForTickers(['HIMS'])
  4. upsert into asset_signals
  5. return enriched result with real price
```

### bootstrap_priority tiers
| Priority | Assets | Count | When fetched |
|---|---|---|---|
| 1 | Top 100 S&P 500 by market cap | ~100 | Bootstrap step 4 (priority=1) |
| 2 | Top ETFs by AUM | ~70 | Bootstrap step 4 (priority=2) |
| 3 | Top 20 cryptos | 20 | Bootstrap step 4 (priority=3) |
| 4 | Rest of S&P 500 | ~350 | Bootstrap step 4 (priority=4) or on-demand |

### Search behaviour
- Typing 1+ characters queries `assets` table via Postgres `ILIKE` (trigram-accelerated)
- Results include price data if it exists in `asset_signals`
- If `?fetch=true` and ≤5 results have no price → triggers live Polygon fetch (on-demand)
- Exact ticker match is ranked first in results

### Daily cron refresh
The ingest cron (`/api/cron/ingest`) already upserts prices for `assets` where
`bootstrap_priority <= 3` (the top ~190 most important assets). The rest get
refreshed lazily — either on search (?fetch=true) or when a user adds them to portfolio.

---

## Polygon free tier coverage notes

| Asset type | Coverage |
|---|---|
| US stocks (NYSE, NASDAQ, AMEX) | ✓ All S&P 500 tickers work |
| US ETFs | ✓ All major ETFs work |
| Crypto | ✓ BTC, ETH, SOL, ADA, DOGE, LINK, LTC reliably; others vary |
| International ADRs (TSM, ASML, SAP) | ✓ Works (listed on US exchanges) |
| OTC/pink sheets | ✗ Not on free tier |

If a ticker returns no data from Polygon, it's stored with `has_data: false` and
shown in the screener without a price (the `—` placeholder).

---

## Phase 2 enhancements

1. **CoinGecko fallback for crypto** — use `COINGECKO_ID_MAP` in `polygon_crypto_map_update.ts` for cryptos not available on Polygon. Zero API cost, 50 req/min free.
2. **Sector-based event signals** — combine `assets.sector` with `events.sectors` to show event-driven signals even for assets without direct ticker mentions.
3. **User-requested tickers outside universe** — if search returns 0 results from `assets` table, attempt a live Polygon lookup and insert into assets if found.
4. **Market cap data** — Polygon `/v3/reference/tickers` endpoint has shares_outstanding → calculate real market cap for ranking.
