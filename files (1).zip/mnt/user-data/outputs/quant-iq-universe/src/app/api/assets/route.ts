/**
 * app/api/assets/route.ts  (updated for universe)
 *
 * GET /api/assets
 *
 * Browse mode — returns paginated assets with price signals.
 * Replaces the old version which only returned 23 seeded rows.
 *
 * Now supports:
 *  - pagination (?offset=50&limit=50)
 *  - universe total count in meta
 *  - assets without prices are included (has_real_price: false)
 *    so the screener shows the full universe even before bootstrap is done
 *
 * Query params:
 *   type        : stock | etf | crypto | commodity
 *   signal      : buy | watch | hold | avoid  (only returns assets with price data)
 *   sort        : signal_score | change_pct | price (default: signal_score)
 *   limit       : default 50, max 200
 *   offset      : default 0
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

const VALID_TYPES   = ['stock', 'etf', 'crypto', 'commodity'] as const
const VALID_SIGNALS = ['buy', 'watch', 'hold', 'avoid'] as const
const VALID_SORTS   = ['signal_score', 'change_pct', 'price'] as const

type AssetType  = (typeof VALID_TYPES)[number]
type SignalType = (typeof VALID_SIGNALS)[number]
type SortType   = (typeof VALID_SORTS)[number]

export async function GET(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const params = req.nextUrl.searchParams
  const typeParam   = params.get('type')   as AssetType | null
  const signalParam = params.get('signal') as SignalType | null
  const sortParam   = (params.get('sort') ?? 'signal_score') as SortType
  const limit  = Math.min(200, parseInt(params.get('limit')  ?? '50', 10))
  const offset =             parseInt(params.get('offset') ?? '0',  10)

  if (typeParam   && !VALID_TYPES.includes(typeParam))   return NextResponse.json({ error: 'Invalid type'   }, { status: 400 })
  if (signalParam && !VALID_SIGNALS.includes(signalParam)) return NextResponse.json({ error: 'Invalid signal' }, { status: 400 })
  if (!VALID_SORTS.includes(sortParam))                    return NextResponse.json({ error: 'Invalid sort'   }, { status: 400 })

  // 1. Get total universe count for meta
  let countQuery = supabase
    .from('assets')
    .select('ticker', { count: 'exact', head: true })
    .eq('is_active', true)
  if (typeParam) countQuery = countQuery.eq('asset_type', typeParam)

  const { count: universeTotal } = await countQuery

  // 2. Fetch assets with pagination
  let assetsQuery = supabase
    .from('assets')
    .select('ticker, name, asset_type, sector, market_cap_tier, bootstrap_priority')
    .eq('is_active', true)
    .order('bootstrap_priority', { ascending: true, nullsFirst: false })
    .range(offset, offset + limit - 1)

  if (typeParam) assetsQuery = assetsQuery.eq('asset_type', typeParam)

  const { data: assets, error: assetErr } = await assetsQuery
  if (assetErr) return NextResponse.json({ error: assetErr.message }, { status: 500 })
  if (!assets?.length) return NextResponse.json({ assets: [], meta: { total: 0, universe_total: universeTotal ?? 0 } })

  // 3. Load signals
  const tickers = assets.map(a => a.ticker)

  let signalsQuery = supabase
    .from('asset_signals')
    .select('ticker, price, open, high, low, change, change_pct, volume, sparkline_bars, signal, signal_score, price_updated_at, has_data, updated_at')
    .in('ticker', tickers)

  if (signalParam) signalsQuery = signalsQuery.eq('signal', signalParam)

  const { data: signals } = await signalsQuery

  const signalMap = new Map<string, any>()
  for (const s of signals ?? []) signalMap.set(s.ticker, s)

  // 4. Merge + filter on signal if requested
  let enriched = assets
    .map(asset => {
      const sig = signalMap.get(asset.ticker)
      return {
        ticker:          asset.ticker,
        name:            asset.name ?? asset.ticker,
        asset_type:      asset.asset_type,
        sector:          asset.sector ?? null,
        market_cap_tier: asset.market_cap_tier ?? null,
        price:           sig?.price ?? null,
        open:            sig?.open ?? null,
        high:            sig?.high ?? null,
        low:             sig?.low ?? null,
        change:          sig?.change ?? null,
        change_pct:      sig?.change_pct ?? null,
        volume:          sig?.volume ?? null,
        sparkline_bars:  sig?.sparkline_bars ?? [],
        signal:          sig?.signal ?? null,
        signal_score:    sig?.signal_score ?? null,
        price_updated_at: sig?.price_updated_at ?? null,
        last_sync:       sig?.updated_at ?? null,
        has_real_price:  !!sig?.has_data,
      }
    })
    .filter(a => !signalParam || a.signal === signalParam)

  // 5. Sort (assets with prices first, then by sort field)
  enriched.sort((a, b) => {
    // Always put assets with real price data first
    if (a.has_real_price !== b.has_real_price) return a.has_real_price ? -1 : 1
    switch (sortParam) {
      case 'signal_score': return (b.signal_score ?? 0) - (a.signal_score ?? 0)
      case 'change_pct':   return (b.change_pct ?? 0)   - (a.change_pct ?? 0)
      case 'price':        return (b.price ?? 0)         - (a.price ?? 0)
      default: return 0
    }
  })

  const withPrices = enriched.filter(a => a.has_real_price).length

  return NextResponse.json({
    assets: enriched,
    meta: {
      total:            enriched.length,
      universe_total:   universeTotal ?? 0,
      with_real_prices: withPrices,
      last_sync:        signals?.[0]?.updated_at ?? null,
      offset,
      limit,
    },
  })
}
