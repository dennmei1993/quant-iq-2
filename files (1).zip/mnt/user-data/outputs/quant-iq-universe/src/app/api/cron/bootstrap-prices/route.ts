/**
 * app/api/cron/bootstrap-prices/route.ts
 *
 * One-time bootstrap cron — runs ONCE to populate asset_signals for the
 * top-priority assets (priority 1 = top 100 S&P 500, 2 = top ETFs, 3 = crypto).
 *
 * Run manually or schedule once:
 *   curl -H "Authorization: Bearer $CRON_SECRET" \
 *        https://your-app.vercel.app/api/cron/bootstrap-prices?priority=1
 *
 * Use priority query param to run in batches (avoids Vercel timeout):
 *   ?priority=1  → top 100 stocks (~5 batches × 13s = ~65s)
 *   ?priority=2  → top ETFs
 *   ?priority=3  → crypto
 *   ?priority=4  → rest of S&P 500 (run overnight)
 *
 * After bootstrap, the daily ingest cron (/api/cron/ingest) handles ongoing
 * refreshes for all assets with has_data = true.
 *
 * Auth: CRON_SECRET bearer token
 */

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { fetchPricesForTickers, fetchSparklinesForTickers } from '@/lib/polygon'

function isAuthorised(req: NextRequest): boolean {
  const auth = req.headers.get('authorization') ?? ''
  const secret = process.env.CRON_SECRET ?? ''
  return secret.length > 0 && auth === `Bearer ${secret}`
}

// Signal derivation (copied from ingest cron — keep in sync or extract to lib)
function deriveSignal(changePct: number): 'buy' | 'watch' | 'hold' | 'avoid' {
  if (changePct >= 2) return 'buy'
  if (changePct >= 0.5) return 'watch'
  if (changePct >= -1) return 'hold'
  return 'avoid'
}

function deriveSignalScore(changePct: number): number {
  return Math.round(Math.min(100, Math.max(0, 50 + changePct * 10)))
}

export async function GET(req: NextRequest) {
  if (!isAuthorised(req)) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const priorityParam = req.nextUrl.searchParams.get('priority')
  const priority = priorityParam ? parseInt(priorityParam, 10) : 1

  if (isNaN(priority) || priority < 1 || priority > 4) {
    return NextResponse.json(
      { error: 'priority must be 1, 2, 3, or 4' },
      { status: 400 }
    )
  }

  const supabase = createServiceClient()
  const log: string[] = []
  const errors: string[] = []

  log.push(`Starting bootstrap for priority ${priority}...`)

  // 1. Load assets at this priority that don't yet have price data
  const { data: assets, error: assetErr } = await supabase
    .from('assets')
    .select('ticker, asset_type, name')
    .eq('bootstrap_priority', priority)
    .eq('is_active', true)
    .order('ticker')

  if (assetErr) {
    return NextResponse.json({ error: assetErr.message }, { status: 500 })
  }

  if (!assets?.length) {
    return NextResponse.json({
      status: 'ok',
      log: [`No assets found with priority ${priority}`],
      errors: [],
    })
  }

  // 2. Check which ones already have data (skip those)
  const allTickers = assets.map(a => a.ticker)

  const { data: existingSignals } = await supabase
    .from('asset_signals')
    .select('ticker')
    .in('ticker', allTickers)
    .eq('has_data', true)

  const alreadySynced = new Set((existingSignals ?? []).map(s => s.ticker))
  const toFetch = allTickers.filter(t => !alreadySynced.has(t))

  log.push(`Found ${allTickers.length} assets at priority ${priority}`)
  log.push(`Already synced: ${alreadySynced.size}, to fetch: ${toFetch.length}`)

  if (toFetch.length === 0) {
    return NextResponse.json({ status: 'ok', log, errors })
  }

  // 3. Fetch prices (rate-limited — 5/min on free tier)
  log.push(`Fetching prices for ${toFetch.length} tickers...`)
  const prices = await fetchPricesForTickers(toFetch)
  log.push(`Got prices for ${prices.size} / ${toFetch.length} tickers`)

  // 4. Fetch sparklines
  log.push(`Fetching sparklines...`)
  const sparklines = await fetchSparklinesForTickers([...prices.keys()])
  log.push(`Got sparklines for ${sparklines.size} tickers`)

  // 5. Upsert into asset_signals
  const upsertRows = [...prices.keys()].map(t => {
    const p = prices.get(t)!
    const bars = sparklines.get(t) ?? []

    return {
      ticker: t,
      price: p.price,
      open: p.open,
      high: p.high,
      low: p.low,
      change: p.change,
      change_pct: p.change_pct,
      volume: p.volume,
      sparkline_bars: bars,
      signal: deriveSignal(p.change_pct),
      signal_score: deriveSignalScore(p.change_pct),
      price_updated_at: p.updated_at,
      updated_at: new Date().toISOString(),
      has_data: true,
    }
  })

  if (upsertRows.length > 0) {
    const { error: upsertErr } = await supabase
      .from('asset_signals')
      .upsert(upsertRows, { onConflict: 'ticker' })

    if (upsertErr) {
      errors.push(`Upsert failed: ${upsertErr.message}`)
    } else {
      log.push(`Upserted ${upsertRows.length} rows into asset_signals`)
    }
  }

  // 6. Log any tickers that Polygon returned nothing for
  const missed = toFetch.filter(t => !prices.has(t))
  if (missed.length > 0) {
    log.push(`No data from Polygon for: ${missed.join(', ')}`)
    // Mark these as attempted so we don't retry endlessly
    // (Could be delisted, not US-listed, or free-tier gap)
  }

  return NextResponse.json({
    status: errors.length === 0 ? 'ok' : 'partial',
    priority,
    fetched: prices.size,
    missed: missed.length,
    log,
    errors,
    ts: new Date().toISOString(),
  })
}
