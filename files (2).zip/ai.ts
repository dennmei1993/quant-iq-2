/**
 * lib/ai.ts  — updated generateTheme() section
 *
 * Key change: generateTheme() now asks Claude to output a structured
 * ticker_weights array alongside the theme. Each entry has:
 *   { ticker, relevance (0–1), rationale (1 sentence) }
 *
 * This feeds directly into theme_tickers rows.
 *
 * The rest of ai.ts (classifyEvent, generateAdvisoryMemo) is unchanged.
 * Only replace the generateTheme function in your existing lib/ai.ts.
 */

import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

// ─── Types ───────────────────────────────────────────────────────────────────

export interface EventInput {
  headline: string
  ai_summary?: string | null
  event_type?: string | null
  sectors?: string[] | null
  sentiment_score?: number
  impact_level?: string | null
  published_at: string
}

export interface TickerWeight {
  ticker: string       // e.g. "NVDA"
  relevance: number    // 0.0–1.0
  rationale: string    // 1-sentence explanation
}

export interface ThemeOutput {
  name: string
  label: string
  conviction: number           // 0–100
  momentum: string             // strong_up | moderate_up | neutral | moderate_down | strong_down
  brief: string                // 3-4 sentence investment thesis
  candidate_tickers: string[]  // flat list (kept for backward compat)
  ticker_weights: TickerWeight[] // NEW: per-ticker relevance + rationale
}

// ─── generateTheme ────────────────────────────────────────────────────────────

/**
 * Generate an investment theme from a set of recent events.
 *
 * Now returns ticker_weights[] alongside candidate_tickers[].
 * ticker_weights contains relevance scores (0–1) and rationale per ticker.
 *
 * Relevance guide Claude uses:
 *   0.9–1.0  Primary play — direct revenue/earnings exposure to the theme
 *   0.6–0.8  Strong secondary — significant but indirect exposure
 *   0.3–0.5  Thematic exposure — sector/macro tailwind, not primary driver
 *   0.1–0.2  Peripheral — marginal connection, monitor only
 */
export async function generateTheme(
  events: EventInput[],
  timeframe: '1m' | '3m' | '6m'
): Promise<ThemeOutput> {
  const eventSummaries = events
    .slice(0, 20) // cap context window usage
    .map(e => `- ${e.headline}${e.ai_summary ? ` (${e.ai_summary})` : ''}`)
    .join('\n')

  const timeframeLabel = { '1m': '1-month', '3m': '3-month', '6m': '6-month' }[timeframe]

  const prompt = `You are a professional investment analyst. Based on these recent macro and market events, identify the single strongest ${timeframeLabel} investment theme.

RECENT EVENTS:
${eventSummaries}

Respond ONLY with a valid JSON object — no preamble, no markdown, no commentary.

Required fields:
{
  "name": "Short theme name (3-6 words, e.g. 'AI Infrastructure Buildout')",
  "label": "One-word label (e.g. 'BULLISH')",
  "conviction": <integer 0-100>,
  "momentum": "<strong_up|moderate_up|neutral|moderate_down|strong_down>",
  "brief": "3-4 sentence investment thesis explaining why this theme is actionable now.",
  "ticker_weights": [
    {
      "ticker": "TICKER",
      "relevance": <float 0.0-1.0>,
      "rationale": "One sentence explaining this ticker's connection to the theme."
    }
  ]
}

Rules for ticker_weights:
- Include 4–8 US-listed tickers (stocks, ETFs, or crypto)
- relevance scale: 1.0 = primary direct play, 0.7 = strong secondary, 0.4 = thematic/indirect, 0.2 = peripheral
- Order by relevance descending
- Be specific: prefer individual stocks over broad ETFs unless the ETF IS the play
- rationale must be one sentence, investment-relevant, ≤20 words
- Only include tickers you are highly confident are US-listed`

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1024,
    messages: [{ role: 'user', content: prompt }],
  })

  const raw = response.content
    .filter(b => b.type === 'text')
    .map(b => (b as any).text)
    .join('')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim()

  const parsed = JSON.parse(raw) as Omit<ThemeOutput, 'candidate_tickers'>

  // Derive candidate_tickers[] from ticker_weights for backward compatibility
  const candidate_tickers = parsed.ticker_weights.map(tw => tw.ticker)

  return {
    ...parsed,
    candidate_tickers,
    ticker_weights: parsed.ticker_weights,
  }
}

// ─── classifyEvent (unchanged — included for completeness) ───────────────────

export interface ClassificationOutput {
  event_type: string
  sectors: string[]
  sentiment_score: number
  impact_level: string
  tickers: string[]
  ai_summary: string
}

export async function classifyEvent(
  headline: string,
  summary?: string | null
): Promise<ClassificationOutput> {
  const prompt = `Classify this financial news event for investment signal analysis.

HEADLINE: ${headline}
${summary ? `SUMMARY: ${summary}` : ''}

Respond ONLY with a valid JSON object:
{
  "event_type": "<monetary_policy|geopolitical|corporate|economic_data|regulatory>",
  "sectors": ["<affected US market sectors>"],
  "sentiment_score": <float -1.0 to 1.0 for US markets>,
  "impact_level": "<low|medium|high>",
  "tickers": ["<directly affected US-listed tickers, max 5>"],
  "ai_summary": "<1 sentence investment-relevant summary>"
}`

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 512,
    messages: [{ role: 'user', content: prompt }],
  })

  const raw = response.content
    .filter(b => b.type === 'text')
    .map(b => (b as any).text)
    .join('')
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim()

  return JSON.parse(raw) as ClassificationOutput
}

// ─── generateAdvisoryMemo (unchanged) ────────────────────────────────────────

export async function generateAdvisoryMemo(
  holdings: { ticker: string; quantity?: number | null; avg_cost?: number | null }[],
  recentEvents: { headline: string; ai_summary?: string | null; sentiment_score: number; impact_level: string }[],
  macroEnvironment?: string
): Promise<string> {
  const holdingsList = holdings
    .map(h => `${h.ticker}${h.quantity ? ` (${h.quantity} units)` : ''}`)
    .join(', ')

  const eventsList = recentEvents
    .slice(0, 10)
    .map(e => `- ${e.ai_summary ?? e.headline} [${e.impact_level}, sentiment: ${e.sentiment_score.toFixed(2)}]`)
    .join('\n')

  const prompt = `You are a professional investment advisor. Write a concise advisory memo for a portfolio.

PORTFOLIO HOLDINGS: ${holdingsList}

RECENT RELEVANT EVENTS:
${eventsList}

${macroEnvironment ? `MACRO CONTEXT: ${macroEnvironment}` : ''}

Write a 3-4 sentence advisory memo that:
1. Identifies the most significant risk or opportunity from current events
2. Calls out which specific holdings are most affected
3. Suggests a concrete near-term action or watchpoint

Write in professional but direct language. No bullet points. Plain prose only.`

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 512,
    messages: [{ role: 'user', content: prompt }],
  })

  return response.content
    .filter(b => b.type === 'text')
    .map(b => (b as any).text)
    .join('')
    .trim()
}
