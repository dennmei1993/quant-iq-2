/**
 * app/dashboard/themes/page.tsx  — updated with ticker weight display
 *
 * Shows themes grouped by timeframe, each with an expandable ticker list
 * showing relevance, computed weight, final_weight as a visual bar,
 * and an inline slider to set manual_weight override.
 */

'use client'

import { useEffect, useState, useCallback } from 'react'
import styles from './themes.module.css'

// ─── Types ───────────────────────────────────────────────────────────────────

interface TickerWeight {
  ticker: string
  relevance: number
  conviction_pct: number
  weight: number
  manual_weight: number | null
  final_weight: number
  rationale: string | null
  added_by: string
  is_overridden: boolean
}

interface Theme {
  id: string
  name: string
  timeframe: '1m' | '3m' | '6m'
  conviction: number
  momentum: string
  brief: string
  candidate_tickers: string[]
  tickers: TickerWeight[]
  expires_at: string | null
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const TIMEFRAME_LABELS: Record<string, string> = {
  '1m': '1 Month',
  '3m': '3 Months',
  '6m': '6 Months',
}

const MOMENTUM_MAP: Record<string, { label: string; cls: string }> = {
  strong_up:     { label: '↑↑ Strong up',    cls: styles.momStrongUp },
  moderate_up:   { label: '↑ Moderate up',   cls: styles.momModUp },
  neutral:       { label: '→ Neutral',        cls: styles.momNeutral },
  moderate_down: { label: '↓ Moderate down', cls: styles.momModDown },
  strong_down:   { label: '↓↓ Strong down',  cls: styles.momStrongDown },
}

function WeightBar({ value, isOverride }: { value: number; isOverride: boolean }) {
  const pct = Math.round(value * 100)
  const color = isOverride ? '#2060a8' : '#c8a96e'
  return (
    <div className={styles.weightBarWrap} title={`${pct}%${isOverride ? ' (manual override)' : ''}`}>
      <div className={styles.weightBarBg}>
        <div
          className={styles.weightBarFill}
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      <span className={styles.weightPct} style={{ color }}>
        {(value).toFixed(2)}
        {isOverride && <span className={styles.overrideDot}>●</span>}
      </span>
    </div>
  )
}

// ─── Ticker weight row with inline override ───────────────────────────────────

function TickerRow({
  themeId,
  tw,
  onUpdated,
}: {
  themeId: string
  tw: TickerWeight
  onUpdated: (ticker: string, newWeight: TickerWeight) => void
}) {
  const [editing, setEditing]   = useState(false)
  const [draft, setDraft]       = useState<number>(tw.manual_weight ?? tw.weight)
  const [saving, setSaving]     = useState(false)
  const [err, setErr]           = useState<string | null>(null)

  async function save() {
    setSaving(true); setErr(null)
    try {
      const res = await fetch(`/api/themes/${themeId}/tickers/${tw.ticker}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ manual_weight: draft }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      onUpdated(tw.ticker, { ...tw, ...data.ticker_weight })
      setEditing(false)
    } catch (e: any) {
      setErr(e.message)
    } finally {
      setSaving(false)
    }
  }

  async function clearOverride() {
    setSaving(true); setErr(null)
    try {
      const res = await fetch(`/api/themes/${themeId}/tickers/${tw.ticker}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ manual_weight: null }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      onUpdated(tw.ticker, { ...tw, ...data.ticker_weight })
      setEditing(false)
    } catch (e: any) {
      setErr(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className={styles.tickerRow}>
      <div className={styles.tickerMain}>
        <span className={styles.tickerSymbol}>{tw.ticker}</span>

        <div className={styles.tickerWeights}>
          <span className={styles.weightLabel}>Relevance</span>
          <WeightBar value={tw.relevance} isOverride={false} />

          <span className={styles.weightLabel}>Computed</span>
          <WeightBar value={tw.weight} isOverride={false} />

          <span className={styles.weightLabel}>Final</span>
          <WeightBar value={tw.final_weight} isOverride={tw.is_overridden} />
        </div>

        <div className={styles.tickerActions}>
          {!editing ? (
            <button className={styles.editBtn} onClick={() => { setDraft(tw.manual_weight ?? tw.weight); setEditing(true) }}>
              {tw.is_overridden ? 'Edit override' : 'Override'}
            </button>
          ) : (
            <div className={styles.overrideForm}>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={draft}
                className={styles.weightSlider}
                onChange={e => setDraft(parseFloat(e.target.value))}
              />
              <span className={styles.draftVal}>{draft.toFixed(2)}</span>
              <button className={styles.saveBtn} onClick={save} disabled={saving}>
                {saving ? '…' : 'Save'}
              </button>
              <button className={styles.cancelBtn} onClick={() => setEditing(false)}>Cancel</button>
              {tw.is_overridden && (
                <button className={styles.clearBtn} onClick={clearOverride} disabled={saving}>
                  Clear override
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {tw.rationale && (
        <p className={styles.rationale}>{tw.rationale}</p>
      )}

      {err && <p className={styles.rowErr}>{err}</p>}
    </div>
  )
}

// ─── Theme card ───────────────────────────────────────────────────────────────

function ThemeCard({ theme, onTickerUpdated }: {
  theme: Theme
  onTickerUpdated: (themeId: string, ticker: string, updated: TickerWeight) => void
}) {
  const [expanded, setExpanded] = useState(false)
  const momentum = MOMENTUM_MAP[theme.momentum] ?? { label: theme.momentum, cls: '' }

  return (
    <div className={styles.themeCard}>
      <div className={styles.themeHeader} onClick={() => setExpanded(e => !e)}>
        <div className={styles.themeLeft}>
          <h3 className={styles.themeName}>{theme.name}</h3>
          <span className={`${styles.momBadge} ${momentum.cls}`}>{momentum.label}</span>
        </div>
        <div className={styles.themeRight}>
          <div className={styles.convictionWrap}>
            <span className={styles.convLabel}>Conviction</span>
            <div className={styles.convBarBg}>
              <div className={styles.convBarFill} style={{ width: `${theme.conviction}%` }} />
            </div>
            <span className={styles.convNum}>{theme.conviction}</span>
          </div>
          <span className={styles.expandChevron}>{expanded ? '↑' : '↓'}</span>
        </div>
      </div>

      <p className={styles.themeBrief}>{theme.brief}</p>

      {expanded && (
        <div className={styles.tickerSection}>
          <div className={styles.tickerSectionHeader}>
            <span>Tickers</span>
            <span className={styles.weightLegend}>
              <span className={styles.legendDot} style={{ background: '#c8a96e' }} /> computed
              <span className={styles.legendDot} style={{ background: '#2060a8', marginLeft: 8 }} /> manual override
            </span>
          </div>
          {theme.tickers.length === 0 ? (
            <p className={styles.noTickers}>
              No ticker weights synced yet — run the themes cron to populate.
            </p>
          ) : (
            theme.tickers.map(tw => (
              <TickerRow
                key={tw.ticker}
                themeId={theme.id}
                tw={tw}
                onUpdated={(ticker, updated) => onTickerUpdated(theme.id, ticker, updated)}
              />
            ))
          )}
        </div>
      )}

      {theme.expires_at && (
        <p className={styles.expiry}>
          Expires {new Date(theme.expires_at).toLocaleDateString()}
        </p>
      )}
    </div>
  )
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function ThemesPage() {
  const [themes, setThemes]   = useState<Theme[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState<string | null>(null)
  const [tfFilter, setTfFilter] = useState<'all' | '1m' | '3m' | '6m'>('all')

  const load = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const p = new URLSearchParams({ weights: 'true' })
      if (tfFilter !== 'all') p.set('timeframe', tfFilter)
      const res = await fetch(`/api/themes?${p}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setThemes(data.themes ?? [])
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [tfFilter])

  useEffect(() => { load() }, [load])

  function handleTickerUpdated(themeId: string, ticker: string, updated: TickerWeight) {
    setThemes(prev => prev.map(t => {
      if (t.id !== themeId) return t
      return {
        ...t,
        tickers: t.tickers.map(tw => tw.ticker === ticker ? updated : tw),
      }
    }))
  }

  const grouped = (['1m', '3m', '6m'] as const).reduce((acc, tf) => {
    acc[tf] = themes.filter(t => t.timeframe === tf)
    return acc
  }, {} as Record<string, Theme[]>)

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Investment Themes</h1>
        <p className={styles.sub}>
          AI-generated themes with per-ticker conviction weights.
          Click a theme to see tickers and override weights.
        </p>
      </div>

      <div className={styles.filterBar}>
        {(['all', '1m', '3m', '6m'] as const).map(tf => (
          <button
            key={tf}
            className={`${styles.filterBtn} ${tfFilter === tf ? styles.filterBtnActive : ''}`}
            onClick={() => setTfFilter(tf)}
          >
            {tf === 'all' ? 'All horizons' : TIMEFRAME_LABELS[tf]}
          </button>
        ))}
      </div>

      {loading && <div className={styles.loading}>Loading themes…</div>}
      {error   && <div className={styles.error}>{error}</div>}

      {!loading && !error && (
        <>
          {(['1m', '3m', '6m'] as const).map(tf => {
            const tfThemes = grouped[tf]
            if ((tfFilter !== 'all' && tfFilter !== tf) || !tfThemes?.length) return null
            return (
              <div key={tf} className={styles.tfSection}>
                <h2 className={styles.tfLabel}>{TIMEFRAME_LABELS[tf]} horizon</h2>
                {tfThemes.map(theme => (
                  <ThemeCard
                    key={theme.id}
                    theme={theme}
                    onTickerUpdated={handleTickerUpdated}
                  />
                ))}
              </div>
            )
          })}

          {themes.length === 0 && (
            <div className={styles.empty}>
              No active themes. Run the themes cron to generate them.
            </div>
          )}
        </>
      )}
    </div>
  )
}
