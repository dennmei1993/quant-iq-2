-- ============================================================================
-- supabase/migrations/004_theme_tickers.sql
--
-- Introduces the theme_tickers junction table (Option C hybrid).
--
-- Weight model:
--   relevance       float4  0–1   AI-assigned: how central is this ticker to the theme
--   conviction_pct  float4  0–1   Derived from themes.conviction (e.g. 72 → 0.72)
--   weight          float4  0–1   COMPUTED: relevance × conviction_pct
--   manual_weight   float4  0–1   NULL unless a human overrides; takes full precedence
--   final_weight    GENERATED: COALESCE(manual_weight, weight)
--
-- Source precedence:
--   manual_weight IS NOT NULL  →  final_weight = manual_weight  (human wins)
--   manual_weight IS NULL      →  final_weight = relevance × conviction_pct
--
-- added_by: 'ai' | 'cron' | 'manual'
-- ============================================================================

-- ── 1. theme_tickers junction table ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS theme_tickers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  theme_id        uuid NOT NULL REFERENCES themes(id) ON DELETE CASCADE,
  ticker          text NOT NULL REFERENCES assets(ticker) ON DELETE CASCADE,

  -- Weight components
  relevance       float4 NOT NULL DEFAULT 1.0
                    CHECK (relevance >= 0 AND relevance <= 1),

  conviction_pct  float4 NOT NULL DEFAULT 1.0
                    CHECK (conviction_pct >= 0 AND conviction_pct <= 1),

  -- Computed weight: relevance × conviction_pct
  -- Updated whenever either component changes
  weight          float4 NOT NULL DEFAULT 1.0
                    CHECK (weight >= 0 AND weight <= 1),

  -- Human override — NULL means "use computed weight"
  manual_weight   float4
                    CHECK (manual_weight IS NULL OR (manual_weight >= 0 AND manual_weight <= 1)),

  -- Effective weight: manual takes precedence over computed
  -- This is a generated column for easy querying
  final_weight    float4 GENERATED ALWAYS AS (
                    COALESCE(manual_weight, weight)
                  ) STORED,

  -- Provenance
  added_by        text NOT NULL DEFAULT 'ai'
                    CHECK (added_by IN ('ai', 'cron', 'manual')),

  -- AI rationale: why Claude included this ticker
  rationale       text,

  -- Cron recalculation audit
  last_recalculated_at  timestamptz,

  -- Standard timestamps
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),

  -- One row per (theme, ticker) — no duplicates
  UNIQUE (theme_id, ticker)
);

COMMENT ON TABLE theme_tickers IS
  'Junction table linking investment themes to their constituent tickers.
   Expands themes.candidate_tickers[] into queryable rows with per-ticker weights.';

COMMENT ON COLUMN theme_tickers.relevance IS
  'AI-assigned score (0–1): how central/relevant this ticker is to the theme.
   1.0 = primary play, 0.5 = indirect exposure, 0.2 = marginal mention.
   Set by Claude during theme generation via structured JSON output.';

COMMENT ON COLUMN theme_tickers.conviction_pct IS
  'Derived from themes.conviction (integer 0–100) normalised to 0–1.
   E.g. theme conviction=72 → conviction_pct=0.72.
   Recalculated by cron when the parent theme conviction changes.';

COMMENT ON COLUMN theme_tickers.weight IS
  'Computed weight = relevance × conviction_pct.
   Represents overall signal strength for this ticker within this theme.
   Recalculated by cron daily.';

COMMENT ON COLUMN theme_tickers.manual_weight IS
  'Human override. When set, REPLACES the computed weight entirely.
   NULL = use computed weight. Set via PATCH /api/themes/:id/tickers/:ticker.';

COMMENT ON COLUMN theme_tickers.final_weight IS
  'Effective weight used by all queries: COALESCE(manual_weight, weight).
   This is the single value consumers should read.';

COMMENT ON COLUMN theme_tickers.rationale IS
  'Claude-generated explanation of why this ticker belongs in this theme.
   E.g. "NVDA is the primary infrastructure play for the AI Capex theme — ~40%
   of hyperscaler GPU spend flows through Nvidia."';

-- ── 2. Indexes ────────────────────────────────────────────────────────────────

-- Primary lookup: "all tickers for a theme" (theme page)
CREATE INDEX IF NOT EXISTS theme_tickers_theme_id_idx
  ON theme_tickers (theme_id, final_weight DESC);

-- Reverse lookup: "all themes for a ticker" (screener, portfolio risk)
CREATE INDEX IF NOT EXISTS theme_tickers_ticker_idx
  ON theme_tickers (ticker, final_weight DESC);

-- High-conviction tickers across all active themes (screener ranking)
CREATE INDEX IF NOT EXISTS theme_tickers_weight_idx
  ON theme_tickers (final_weight DESC)
  WHERE final_weight > 0.3;

-- ── 3. RLS policies ───────────────────────────────────────────────────────────

ALTER TABLE theme_tickers ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can read theme_tickers (same as themes table)
CREATE POLICY "Authenticated users can read theme_tickers"
  ON theme_tickers FOR SELECT
  TO authenticated
  USING (true);

-- Only service role (cron, admin) can insert/update/delete
-- (No direct user writes — users read; cron + AI write)
-- Service role bypasses RLS by default — no insert policy needed.

-- ── 4. updated_at trigger ─────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_theme_tickers_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  -- Recompute weight whenever relevance or conviction_pct changes
  -- (generated column handles final_weight, but weight itself is NOT generated
  --  because it depends on two mutable columns — we recompute here)
  IF NEW.relevance IS DISTINCT FROM OLD.relevance
  OR NEW.conviction_pct IS DISTINCT FROM OLD.conviction_pct THEN
    NEW.weight = NEW.relevance * NEW.conviction_pct;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER theme_tickers_updated_at
  BEFORE UPDATE ON theme_tickers
  FOR EACH ROW
  EXECUTE FUNCTION update_theme_tickers_updated_at();

-- ── 5. Backfill: expand existing themes.candidate_tickers[] ──────────────────
-- Inserts one theme_ticker row per ticker in candidate_tickers[],
-- with weight = 1.0 × (conviction/100) as the initial value.
-- relevance defaults to 1.0 (unknown until AI re-scores).
-- Safe to re-run (ON CONFLICT DO NOTHING).

INSERT INTO theme_tickers (
  theme_id, ticker, relevance, conviction_pct, weight, added_by
)
SELECT
  t.id                            AS theme_id,
  unnest(t.candidate_tickers)     AS ticker,
  1.0                             AS relevance,
  COALESCE(t.conviction, 50) / 100.0  AS conviction_pct,
  1.0 * COALESCE(t.conviction, 50) / 100.0  AS weight,
  'cron'                          AS added_by
FROM themes t
WHERE t.candidate_tickers IS NOT NULL
  AND array_length(t.candidate_tickers, 1) > 0
  -- Only include tickers that exist in the assets table
  -- (avoids FK violation for free-text tickers not yet seeded)
ON CONFLICT (theme_id, ticker) DO NOTHING;

-- ── 6. Verify ─────────────────────────────────────────────────────────────────
-- After running, confirm with:
--
-- SELECT t.name, t.conviction, tt.ticker, tt.relevance,
--        tt.conviction_pct, tt.weight, tt.final_weight
-- FROM theme_tickers tt
-- JOIN themes t ON t.id = tt.theme_id
-- ORDER BY t.name, tt.final_weight DESC
-- LIMIT 30;
