/**
 * app/api/themes/route.ts
 *
 * GET  /api/themes           — fetch active themes with ticker weights
 * GET  /api/themes?ticker=NVDA — themes that include a specific ticker
 *
 * app/api/themes/[id]/tickers/[ticker]/route.ts handles PATCH for manual weight
 * (see separate file)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const params = req.nextUrl.searchParams
  const timeframe = params.get('timeframe')   // 1m | 3m | 6m
  const ticker    = params.get('ticker')       // filter to themes containing this ticker
  const withWeights = params.get('weights') !== 'false' // default true

  // Build themes query
  let themesQuery = supabase
    .from('themes')
    .select('id, name, timeframe, conviction, momentum, brief, candidate_tickers, is_active, expires_at, created_at')
    .eq('is_active', true)
    .order('conviction', { ascending: false })

  if (timeframe && ['1m', '3m', '6m'].includes(timeframe)) {
    themesQuery = themesQuery.eq('timeframe', timeframe)
  }

  // If filtering by ticker, first find theme_ids that include it
  if (ticker) {
    const { data: themeTickerRows } = await supabase
      .from('theme_tickers')
      .select('theme_id')
      .eq('ticker', ticker.toUpperCase())

    const themeIds = (themeTickerRows ?? []).map(r => r.theme_id)
    if (!themeIds.length) return NextResponse.json({ themes: [] })

    themesQuery = themesQuery.in('id', themeIds)
  }

  const { data: themes, error: themesErr } = await themesQuery

  if (themesErr) {
    return NextResponse.json({ error: themesErr.message }, { status: 500 })
  }

  if (!themes?.length) return NextResponse.json({ themes: [] })

  // Optionally enrich with ticker weights
  if (!withWeights) {
    return NextResponse.json({ themes })
  }

  const themeIds = themes.map(t => t.id)

  const { data: tickerRows } = await supabase
    .from('theme_tickers')
    .select('theme_id, ticker, relevance, conviction_pct, weight, manual_weight, final_weight, rationale, added_by')
    .in('theme_id', themeIds)
    .order('final_weight', { ascending: false })

  // Group ticker rows by theme_id
  const tickersByTheme = new Map<string, any[]>()
  for (const row of tickerRows ?? []) {
    if (!tickersByTheme.has(row.theme_id)) tickersByTheme.set(row.theme_id, [])
    tickersByTheme.get(row.theme_id)!.push(row)
  }

  const enriched = themes.map(theme => ({
    ...theme,
    tickers: (tickersByTheme.get(theme.id) ?? []).map(row => ({
      ticker:        row.ticker,
      relevance:     row.relevance,
      conviction_pct: row.conviction_pct,
      weight:        row.weight,
      manual_weight: row.manual_weight,
      final_weight:  row.final_weight,
      rationale:     row.rationale,
      added_by:      row.added_by,
      is_overridden: row.manual_weight !== null,
    })),
  }))

  return NextResponse.json({ themes: enriched })
}
