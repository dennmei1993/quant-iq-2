/**
 * app/api/themes/[id]/tickers/[ticker]/route.ts
 *
 * PATCH /api/themes/:themeId/tickers/:ticker
 *
 * Allows manual override of a ticker's weight within a theme.
 *
 * Body:
 *   { manual_weight: number | null }
 *
 *   manual_weight: 0.0–1.0  → sets override (final_weight = manual_weight)
 *   manual_weight: null      → clears override (final_weight = computed weight)
 *
 * Auth: requires valid session (any authenticated user for now;
 * restrict to admin role in production via profiles.plan check).
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { z } from 'zod'

const PatchSchema = z.object({
  manual_weight: z.union([
    z.number().min(0).max(1),
    z.null(),
  ]),
})

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string; ticker: string } }
) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const { id: themeId, ticker } = params

  // Validate body
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  const parsed = PatchSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 })
  }

  const { manual_weight } = parsed.data
  const tickerUpper = ticker.toUpperCase()

  // Confirm the theme_ticker row exists
  const { data: existing, error: fetchErr } = await supabase
    .from('theme_tickers')
    .select('id, weight, relevance, conviction_pct, manual_weight, added_by')
    .eq('theme_id', themeId)
    .eq('ticker', tickerUpper)
    .maybeSingle()

  if (fetchErr) {
    return NextResponse.json({ error: fetchErr.message }, { status: 500 })
  }
  if (!existing) {
    return NextResponse.json(
      { error: `No theme_ticker found for theme ${themeId} + ticker ${tickerUpper}` },
      { status: 404 }
    )
  }

  // Apply the update
  const { data: updated, error: updateErr } = await supabase
    .from('theme_tickers')
    .update({
      manual_weight,
      added_by:   manual_weight !== null ? 'manual' : existing.added_by,
      updated_at: new Date().toISOString(),
    })
    .eq('theme_id', themeId)
    .eq('ticker', tickerUpper)
    .select('ticker, relevance, conviction_pct, weight, manual_weight, final_weight, added_by')
    .single()

  if (updateErr) {
    return NextResponse.json({ error: updateErr.message }, { status: 500 })
  }

  return NextResponse.json({
    ticker_weight: {
      ...updated,
      is_overridden: updated.manual_weight !== null,
    },
    message: manual_weight !== null
      ? `Manual weight ${manual_weight.toFixed(2)} applied to ${tickerUpper}`
      : `Manual override cleared — ${tickerUpper} reverts to computed weight ${existing.weight.toFixed(3)}`,
  })
}

/**
 * DELETE /api/themes/:themeId/tickers/:ticker
 *
 * Removes a ticker from a theme entirely (soft: sets relevance to 0,
 * or hard: deletes the row — using hard delete here).
 * Only sensible for manually-managed tickers.
 */
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string; ticker: string } }
) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const { id: themeId, ticker } = params

  const { error: deleteErr } = await supabase
    .from('theme_tickers')
    .delete()
    .eq('theme_id', themeId)
    .eq('ticker', ticker.toUpperCase())

  if (deleteErr) {
    return NextResponse.json({ error: deleteErr.message }, { status: 500 })
  }

  return NextResponse.json({ deleted: true })
}
