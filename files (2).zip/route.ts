/**
 * app/api/cron/themes/route.ts  — updated with theme_tickers sync
 *
 * Flow:
 *  1. Fetch last 48h of high/medium impact events (unchanged)
 *  2. For each timeframe (1m, 3m, 6m):
 *     a. Deactivate existing themes for that timeframe
 *     b. Call generateTheme() → now returns ticker_weights[]
 *     c. Insert new theme row (with candidate_tickers[] for backward compat)
 *     d. NEW: Sync theme_tickers rows with computed weights
 *  3. NEW: Daily recalculation of weights for all active theme_tickers
 *
 * Auth: CRON_SECRET bearer token
 */

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { generateTheme, type TickerWeight } from '@/lib/ai'

function isAuthorised(req: NextRequest): boolean {
  const auth = req.headers.get('authorization') ?? ''
  const secret = process.env.CRON_SECRET ?? ''
  return secret.length > 0 && auth === `Bearer ${secret}`
}

// Expiry windows per timeframe
const EXPIRY_HOURS: Record<string, number> = {
  '1m': 24,
  '3m': 72,
  '6m': 168,
}

export async function GET(req: NextRequest) {
  if (!isAuthorised(req)) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const supabase = createServiceClient()
  const log: string[] = []
  const errors: string[] = []

  // ── Step 1: Fetch recent high/medium events ───────────────────────────────

  const since = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()

  const { data: events, error: eventsErr } = await supabase
    .from('events')
    .select('id, headline, ai_summary, event_type, sectors, sentiment_score, impact_level, published_at')
    .eq('ai_processed', true)
    .in('impact_level', ['high', 'medium'])
    .gte('published_at', since)
    .order('published_at', { ascending: false })
    .limit(60)

  if (eventsErr) {
    return NextResponse.json({ error: `Failed to fetch events: ${eventsErr.message}` }, { status: 500 })
  }

  if (!events?.length) {
    return NextResponse.json({ status: 'ok', log: ['No recent events — skipping theme generation'] })
  }

  log.push(`Processing ${events.length} events for theme generation`)

  // ── Step 2: Generate themes for each timeframe ────────────────────────────

  const timeframes = ['1m', '3m', '6m'] as const

  for (const tf of timeframes) {
    log.push(`Generating ${tf} theme...`)

    try {
      // a. Deactivate existing themes for this timeframe
      const { error: deactivateErr } = await supabase
        .from('themes')
        .update({ is_active: false })
        .eq('timeframe', tf)
        .eq('is_active', true)

      if (deactivateErr) {
        errors.push(`Failed to deactivate ${tf} themes: ${deactivateErr.message}`)
        continue
      }

      // b. Generate theme with per-ticker weights
      const theme = await generateTheme(events, tf)

      log.push(
        `${tf} theme: "${theme.name}" — conviction ${theme.conviction}, ` +
        `${theme.ticker_weights.length} tickers with weights`
      )

      // c. Insert new theme row
      const expiresAt = new Date(
        Date.now() + EXPIRY_HOURS[tf] * 60 * 60 * 1000
      ).toISOString()

      const { data: newTheme, error: insertErr } = await supabase
        .from('themes')
        .insert({
          name:              theme.name,
          timeframe:         tf,
          conviction:        theme.conviction,
          momentum:          theme.momentum,
          brief:             theme.brief,
          candidate_tickers: theme.candidate_tickers, // backward compat array
          is_active:         true,
          expires_at:        expiresAt,
        })
        .select('id')
        .single()

      if (insertErr || !newTheme) {
        errors.push(`Failed to insert ${tf} theme: ${insertErr?.message}`)
        continue
      }

      // d. Sync theme_tickers with computed weights
      const syncResult = await syncThemeTickers(
        supabase,
        newTheme.id,
        theme.conviction,
        theme.ticker_weights
      )

      log.push(
        `${tf} theme_tickers: ${syncResult.inserted} inserted, ` +
        `${syncResult.skipped} skipped (not in assets table)`
      )
      if (syncResult.errors.length) {
        errors.push(...syncResult.errors)
      }

    } catch (err) {
      errors.push(`${tf} theme generation failed: ${String(err)}`)
    }
  }

  // ── Step 3: Daily weight recalculation for all active themes ──────────────
  // Updates conviction_pct and weight for existing rows whose parent
  // theme conviction may have drifted (e.g. manually edited themes).

  log.push('Running daily weight recalculation...')

  try {
    const recalcCount = await recalculateActiveWeights(supabase)
    log.push(`Recalculated weights for ${recalcCount} theme_ticker rows`)
  } catch (err) {
    errors.push(`Weight recalculation failed: ${String(err)}`)
  }

  const status = errors.length === 0 ? 'ok' : 'partial'
  console.log('[cron/themes]', { status, log, errors })

  return NextResponse.json({ status, log, errors, ts: new Date().toISOString() })
}

// ─── syncThemeTickers ────────────────────────────────────────────────────────

interface SyncResult {
  inserted: number
  skipped: number
  errors: string[]
}

async function syncThemeTickers(
  supabase: ReturnType<typeof createServiceClient>,
  themeId: string,
  conviction: number,
  tickerWeights: TickerWeight[]
): Promise<SyncResult> {
  const result: SyncResult = { inserted: 0, skipped: 0, errors: [] }

  if (!tickerWeights.length) return result

  const convictionPct = conviction / 100

  // Validate tickers exist in assets table to avoid FK violations
  const tickers = tickerWeights.map(tw => tw.ticker.toUpperCase())

  const { data: validAssets } = await supabase
    .from('assets')
    .select('ticker')
    .in('ticker', tickers)

  const validTickers = new Set((validAssets ?? []).map(a => a.ticker.toUpperCase()))

  const rowsToInsert = tickerWeights
    .filter(tw => {
      const upper = tw.ticker.toUpperCase()
      if (!validTickers.has(upper)) {
        result.skipped++
        return false
      }
      return true
    })
    .map(tw => {
      const relevance = Math.max(0, Math.min(1, tw.relevance))
      const weight    = relevance * convictionPct

      return {
        theme_id:       themeId,
        ticker:         tw.ticker.toUpperCase(),
        relevance,
        conviction_pct: convictionPct,
        weight,
        // manual_weight stays NULL — AI-assigned only at creation
        rationale:      tw.rationale ?? null,
        added_by:       'ai' as const,
        last_recalculated_at: new Date().toISOString(),
      }
    })

  if (!rowsToInsert.length) return result

  const { error: upsertErr } = await supabase
    .from('theme_tickers')
    .upsert(rowsToInsert, {
      onConflict: 'theme_id,ticker',
      // On conflict: update weights but preserve manual_weight if set
      ignoreDuplicates: false,
    })

  if (upsertErr) {
    result.errors.push(`theme_tickers upsert failed: ${upsertErr.message}`)
  } else {
    result.inserted = rowsToInsert.length
  }

  return result
}

// ─── recalculateActiveWeights ─────────────────────────────────────────────────

/**
 * Re-derives conviction_pct from the parent theme's current conviction value,
 * then recomputes weight = relevance × conviction_pct.
 *
 * Skips rows with manual_weight set (human overrides are respected).
 *
 * Returns the number of rows updated.
 */
async function recalculateActiveWeights(
  supabase: ReturnType<typeof createServiceClient>
): Promise<number> {
  // Fetch all active theme tickers joined with parent theme conviction
  const { data: rows, error } = await supabase
    .from('theme_tickers')
    .select(`
      id,
      relevance,
      conviction_pct,
      weight,
      manual_weight,
      themes!inner ( conviction, is_active )
    `)
    .is('manual_weight', null) // never touch manual overrides
    .eq('themes.is_active', true)

  if (error) throw new Error(`Fetch for recalc failed: ${error.message}`)
  if (!rows?.length) return 0

  let updated = 0

  // Batch updates — group rows that need changing
  const toUpdate = rows.filter(row => {
    const theme = (row as any).themes
    const freshConvictionPct = (theme?.conviction ?? 50) / 100
    const freshWeight = row.relevance * freshConvictionPct

    // Only update if values have meaningfully changed (avoid pointless writes)
    return (
      Math.abs(freshConvictionPct - row.conviction_pct) > 0.001 ||
      Math.abs(freshWeight - row.weight) > 0.001
    )
  })

  for (const row of toUpdate) {
    const theme = (row as any).themes
    const freshConvictionPct = (theme?.conviction ?? 50) / 100
    const freshWeight = row.relevance * freshConvictionPct

    const { error: updateErr } = await supabase
      .from('theme_tickers')
      .update({
        conviction_pct:          freshConvictionPct,
        weight:                  freshWeight,
        last_recalculated_at:    new Date().toISOString(),
        updated_at:              new Date().toISOString(),
      })
      .eq('id', row.id)

    if (!updateErr) updated++
  }

  return updated
}
