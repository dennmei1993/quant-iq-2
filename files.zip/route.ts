/**
 * app/api/cron/ingest/route.ts
 *
 * Daily cron — runs 8am UTC via Vercel Cron (vercel.json).
 *
 * What this does:
 *  1. Fetch news events from NewsAPI (unchanged)
 *  2. Classify each event with Claude AI (unchanged)
 *  3. Store classified events in Supabase (unchanged)
 *  4. NEW: Fetch real prices from Polygon.io for all assets in the assets table
 *  5. NEW: Fetch 30-day sparklines from Polygon.io
 *  6. NEW: Upsert prices + sparklines into asset_signals table
 *  7. NEW: Run alert generation for all users with holdings
 *
 * Auth: CRON_SECRET bearer token (set in Vercel env + vercel.json headers)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { fetchNewsEvents } from '@/lib/ingest'
import { classifyEvent } from '@/lib/ai'
import { fetchPricesForTickers, fetchSparklinesForTickers } from '@/lib/polygon'
import { generateAlertsForAllUsers } from '@/lib/alerts'

// ─── Auth guard ──────────────────────────────────────────────────────────────

function isAuthorised(req: NextRequest): boolean {
  const auth = req.headers.get('authorization') ?? ''
  const secret = process.env.CRON_SECRET ?? ''
  return secret.length > 0 && auth === `Bearer ${secret}`
}

// ─── Main handler ────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  if (!isAuthorised(req)) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const supabase = createServiceClient()
  const log: string[] = []
  const errors: string[] = []

  // ── Step 1–3: News ingest + Claude classification (existing logic) ──────────

  log.push('Starting news ingest...')
  try {
    const rawEvents = await fetchNewsEvents()
    log.push(`Fetched ${rawEvents.length} raw events from NewsAPI`)

    let classified = 0
    let skipped = 0

    for (const event of rawEvents) {
      // Deduplicate by source URL before inserting
      const { data: existing } = await supabase
        .from('events')
        .select('id')
        .eq('url', event.url)
        .maybeSingle()

      if (existing) {
        skipped++
        continue
      }

      // Insert raw event first
      const { data: inserted, error: insertErr } = await supabase
        .from('events')
        .insert({
          headline: event.headline,
          source: 'newsapi',
          url: event.url,
          published_at: event.publishedAt,
          ai_processed: false,
        })
        .select('id')
        .single()

      if (insertErr || !inserted) {
        errors.push(`Insert failed for "${event.headline.slice(0, 60)}": ${insertErr?.message}`)
        continue
      }

      // Classify with Claude (1s delay between calls to avoid rate limiting)
      await new Promise(r => setTimeout(r, 1000))

      try {
        const classification = await classifyEvent(event.headline, event.summary)

        await supabase
          .from('events')
          .update({
            event_type: classification.event_type,
            sectors: classification.sectors,
            sentiment_score: classification.sentiment_score,
            impact_level: classification.impact_level,
            tickers: classification.tickers,
            ai_summary: classification.ai_summary,
            ai_processed: true,
          })
          .eq('id', inserted.id)

        classified++
      } catch (aiErr) {
        errors.push(`Claude classification failed for event ${inserted.id}: ${String(aiErr)}`)
      }
    }

    log.push(`Events: ${classified} classified, ${skipped} deduplicated/skipped`)
  } catch (err) {
    errors.push(`News ingest failed: ${String(err)}`)
  }

  // ── Step 4–6: Polygon.io price + sparkline sync ──────────────────────────

  log.push('Starting Polygon.io price sync...')

  try {
    // Load all tickers from the assets table
    const { data: assets, error: assetErr } = await supabase
      .from('assets')
      .select('ticker, asset_type')

    if (assetErr || !assets?.length) {
      errors.push(`Failed to load assets: ${assetErr?.message ?? 'empty result'}`)
    } else {
      const tickers = assets.map(a => a.ticker)
      log.push(`Fetching prices for ${tickers.length} tickers: ${tickers.join(', ')}`)

      // Fetch prices (rate-limit aware — ~13s between batches of 5)
      const prices = await fetchPricesForTickers(tickers)
      log.push(`Got prices for ${prices.size} / ${tickers.length} tickers`)

      // Fetch sparklines (separate batch cycle — also rate-limited)
      const sparklines = await fetchSparklinesForTickers(tickers)
      log.push(`Got sparklines for ${sparklines.size} / ${tickers.length} tickers`)

      // Upsert into asset_signals table
      // asset_signals schema:
      //   ticker text UNIQUE, price numeric, open numeric, high numeric, low numeric,
      //   change numeric, change_pct numeric, volume bigint,
      //   sparkline_bars jsonb,   ← array of {t,o,h,l,c,v}
      //   signal text,            ← buy | watch | hold | avoid (computed below)
      //   signal_score numeric,   ← 0–100
      //   updated_at timestamptz

      const upsertRows = tickers
        .filter(t => prices.has(t))
        .map(t => {
          const p = prices.get(t)!
          const bars = sparklines.get(t) ?? []
          const signal = deriveSignal(p.change_pct)
          const signal_score = deriveSignalScore(p.change_pct)

          return {
            ticker: t,
            price: p.price,
            open: p.open,
            high: p.high,
            low: p.low,
            change: p.change,
            change_pct: p.change_pct,
            volume: p.volume,
            sparkline_bars: bars,
            signal,
            signal_score,
            price_updated_at: p.updated_at,
            updated_at: new Date().toISOString(),
          }
        })

      if (upsertRows.length > 0) {
        const { error: upsertErr } = await supabase
          .from('asset_signals')
          .upsert(upsertRows, { onConflict: 'ticker' })

        if (upsertErr) {
          errors.push(`asset_signals upsert failed: ${upsertErr.message}`)
        } else {
          log.push(`Upserted ${upsertRows.length} rows into asset_signals`)
        }
      }
    }
  } catch (err) {
    errors.push(`Polygon sync failed: ${String(err)}`)
  }

  // ── Step 7: Auto-alert generation ────────────────────────────────────────

  log.push('Starting auto-alert generation...')
  try {
    const alertsCreated = await generateAlertsForAllUsers(supabase)
    log.push(`Created ${alertsCreated} new alerts across all users`)
  } catch (err) {
    errors.push(`Alert generation failed: ${String(err)}`)
  }

  // ── Done ──────────────────────────────────────────────────────────────────

  const status = errors.length === 0 ? 'ok' : 'partial'
  console.log('[cron/ingest]', { status, log, errors })

  return NextResponse.json({
    status,
    log,
    errors,
    ts: new Date().toISOString(),
  })
}

// ─── Signal derivation from price change ────────────────────────────────────

/**
 * Derive a simple directional signal from the daily % change.
 * In a real implementation you'd combine this with the sentiment_score
 * from recent events hitting that ticker. This is the price-only baseline.
 *
 * For a richer signal, join with events.tickers and weight by recency.
 */
function deriveSignal(changePct: number): 'buy' | 'watch' | 'hold' | 'avoid' {
  if (changePct >= 2) return 'buy'
  if (changePct >= 0.5) return 'watch'
  if (changePct >= -1) return 'hold'
  return 'avoid'
}

/**
 * 0–100 score. Centred at 50 (flat), scales linearly ±5% → 0–100.
 * Clamps at boundaries.
 */
function deriveSignalScore(changePct: number): number {
  const score = 50 + changePct * 10
  return Math.round(Math.min(100, Math.max(0, score)))
}
