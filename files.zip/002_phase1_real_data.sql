-- ============================================================================
-- supabase/migrations/002_phase1_real_data.sql
--
-- Phase 1 additions:
--   1. Extend asset_signals with price columns + sparkline storage
--   2. Add event_id + theme_id + severity + sentiment columns to alerts
--   3. Add url column to events for deduplication
--   4. Add name + asset_type + notes columns to holdings
-- ============================================================================

-- ── 1. asset_signals — extend with real price data ──────────────────────────
-- The existing table likely has: ticker, signal, signal_score, updated_at
-- We add the full OHLCV price fields + sparkline JSON.

ALTER TABLE asset_signals
  ADD COLUMN IF NOT EXISTS price          numeric(14,4),
  ADD COLUMN IF NOT EXISTS open           numeric(14,4),
  ADD COLUMN IF NOT EXISTS high           numeric(14,4),
  ADD COLUMN IF NOT EXISTS low            numeric(14,4),
  ADD COLUMN IF NOT EXISTS change         numeric(10,4),
  ADD COLUMN IF NOT EXISTS change_pct     numeric(8,4),
  ADD COLUMN IF NOT EXISTS volume         bigint,
  ADD COLUMN IF NOT EXISTS sparkline_bars jsonb          DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS price_updated_at timestamptz;

-- GIN index on sparkline_bars is unnecessary (we always read the whole blob)
-- but a regular index on ticker (already unique) covers our queries.

COMMENT ON COLUMN asset_signals.sparkline_bars IS
  'Array of {t,o,h,l,c,v} daily OHLCV bars from Polygon.io — last 30 trading days.';

COMMENT ON COLUMN asset_signals.price IS
  'Previous session close price in USD, sourced from Polygon.io /v2/aggs/prev.';


-- ── 2. alerts — add event linkage + metadata columns ────────────────────────

ALTER TABLE alerts
  ADD COLUMN IF NOT EXISTS event_id   uuid REFERENCES events(id)  ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS theme_id   uuid REFERENCES themes(id)  ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS severity   text CHECK (severity IN ('low','medium','high')),
  ADD COLUMN IF NOT EXISTS sentiment  text CHECK (sentiment IN ('bullish','bearish','neutral')),
  ADD COLUMN IF NOT EXISTS alert_type text,
  ADD COLUMN IF NOT EXISTS title      text,
  ADD COLUMN IF NOT EXISTS message    text;

-- Index for deduplication queries in alerts engine
CREATE INDEX IF NOT EXISTS alerts_user_event_idx ON alerts (user_id, event_id)
  WHERE event_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS alerts_user_theme_idx ON alerts (user_id, theme_id)
  WHERE theme_id IS NOT NULL;

COMMENT ON COLUMN alerts.event_id IS
  'The event that triggered this alert. Used to deduplicate — one alert per (user, event).';

COMMENT ON COLUMN alerts.theme_id IS
  'The theme that triggered this alert (for theme_update type). One alert per (user, theme).';


-- ── 3. events — add url for deduplication ────────────────────────────────────

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS url text;

CREATE UNIQUE INDEX IF NOT EXISTS events_url_unique_idx ON events (url)
  WHERE url IS NOT NULL;

COMMENT ON COLUMN events.url IS
  'Source article URL. Used to deduplicate ingested events across cron runs.';


-- ── 4. holdings — add display fields ─────────────────────────────────────────

ALTER TABLE holdings
  ADD COLUMN IF NOT EXISTS name       text,
  ADD COLUMN IF NOT EXISTS asset_type text CHECK (asset_type IN ('stock','etf','crypto','commodity')),
  ADD COLUMN IF NOT EXISTS notes      text;

COMMENT ON COLUMN holdings.name IS
  'Human-readable display name for the holding e.g. "Apple Inc".';


-- ── 5. RLS policies — alerts new columns (existing policies cover row access) ─
-- No new policies needed — existing "Own read + update" policy on alerts
-- (auth.uid() = user_id) already covers the new columns.


-- ── 6. Verify ────────────────────────────────────────────────────────────────
-- Run these SELECTs manually after migration to confirm columns exist:
--
--   SELECT column_name FROM information_schema.columns
--   WHERE table_name = 'asset_signals' ORDER BY ordinal_position;
--
--   SELECT column_name FROM information_schema.columns
--   WHERE table_name = 'alerts' ORDER BY ordinal_position;
