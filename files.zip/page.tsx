/**
 * app/dashboard/assets/page.tsx
 *
 * Asset Screener — shows real prices, % change, and 30-day sparklines
 * from Polygon.io data (synced daily by the ingest cron).
 *
 * Data flow: GET /api/assets → asset_signals table → this page
 */

'use client'

import { useEffect, useState, useCallback } from 'react'
import styles from './assets.module.css'

// ─── Types ───────────────────────────────────────────────────────────────────

interface SparkBar { t: number; c: number }

interface Asset {
  ticker: string
  name: string
  asset_type: string
  sector: string | null
  price: number | null
  change: number | null
  change_pct: number | null
  volume: number | null
  sparkline_bars: SparkBar[]
  signal: 'buy' | 'watch' | 'hold' | 'avoid'
  signal_score: number
  has_real_price: boolean
  price_updated_at: string | null
}

type FilterType = 'all' | 'stock' | 'etf' | 'crypto' | 'commodity'
type FilterSignal = 'all' | 'buy' | 'watch' | 'hold' | 'avoid'
type SortField = 'signal_score' | 'change_pct' | 'price'

// ─── Sparkline SVG ───────────────────────────────────────────────────────────

function Sparkline({ bars, positive }: { bars: SparkBar[]; positive: boolean }) {
  if (!bars || bars.length < 2) {
    return <span className={styles.sparkPlaceholder}>—</span>
  }

  const W = 80
  const H = 28
  const prices = bars.map(b => b.c)
  const min = Math.min(...prices)
  const max = Math.max(...prices)
  const range = max - min || 1

  const points = prices.map((p, i) => {
    const x = (i / (prices.length - 1)) * W
    const y = H - ((p - min) / range) * H
    return `${x.toFixed(1)},${y.toFixed(1)}`
  })

  const color = positive ? '#1D9E75' : '#E24B4A'

  return (
    <svg
      width={W}
      height={H}
      viewBox={`0 0 ${W} ${H}`}
      style={{ display: 'block' }}
    >
      <polyline
        points={points.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

// ─── Signal badge ─────────────────────────────────────────────────────────────

function SignalBadge({ signal }: { signal: Asset['signal'] }) {
  const map: Record<Asset['signal'], { label: string; cls: string }> = {
    buy: { label: 'BUY', cls: styles.sigBuy },
    watch: { label: 'WATCH', cls: styles.sigWatch },
    hold: { label: 'HOLD', cls: styles.sigHold },
    avoid: { label: 'AVOID', cls: styles.sigAvoid },
  }
  const { label, cls } = map[signal]
  return <span className={`${styles.sigBadge} ${cls}`}>{label}</span>
}

// ─── Page component ───────────────────────────────────────────────────────────

export default function AssetsPage() {
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [typeFilter, setTypeFilter] = useState<FilterType>('all')
  const [signalFilter, setSignalFilter] = useState<FilterSignal>('all')
  const [sortField, setSortField] = useState<SortField>('signal_score')

  const [lastSync, setLastSync] = useState<string | null>(null)
  const [withPrices, setWithPrices] = useState(0)

  const fetchAssets = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams({ sort: sortField })
      if (typeFilter !== 'all') params.set('type', typeFilter)
      if (signalFilter !== 'all') params.set('signal', signalFilter)

      const res = await fetch(`/api/assets?${params}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()

      setAssets(data.assets ?? [])
      setLastSync(data.meta?.last_sync ?? null)
      setWithPrices(data.meta?.with_real_prices ?? 0)
    } catch (err) {
      setError(String(err))
    } finally {
      setLoading(false)
    }
  }, [typeFilter, signalFilter, sortField])

  useEffect(() => { fetchAssets() }, [fetchAssets])

  const fmt = (n: number | null, decimals = 2) =>
    n == null ? '—' : n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })

  const fmtChange = (n: number | null) => {
    if (n == null) return '—'
    const sign = n >= 0 ? '+' : ''
    return `${sign}${n.toFixed(2)}%`
  }

  const fmtVol = (v: number | null) => {
    if (v == null) return '—'
    if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(1)}B`
    if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`
    if (v >= 1_000) return `${(v / 1_000).toFixed(0)}K`
    return String(v)
  }

  return (
    <div className={styles.page}>
      {/* ── Header ── */}
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Asset Screener</h1>
          <p className={styles.sub}>
            {withPrices > 0
              ? `${withPrices} assets with live prices · synced ${lastSync ? new Date(lastSync).toLocaleString() : 'today'}`
              : 'Prices sync daily at 8am UTC via Polygon.io'}
          </p>
        </div>
      </div>

      {/* ── Filters ── */}
      <div className={styles.filterBar}>
        <div className={styles.filterGroup}>
          <span className={styles.filterLabel}>Type</span>
          {(['all', 'stock', 'etf', 'crypto', 'commodity'] as FilterType[]).map(t => (
            <button
              key={t}
              className={`${styles.filterBtn} ${typeFilter === t ? styles.filterBtnActive : ''}`}
              onClick={() => setTypeFilter(t)}
            >
              {t === 'all' ? 'All' : t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>

        <div className={styles.filterGroup}>
          <span className={styles.filterLabel}>Signal</span>
          {(['all', 'buy', 'watch', 'hold', 'avoid'] as FilterSignal[]).map(s => (
            <button
              key={s}
              className={`${styles.filterBtn} ${signalFilter === s ? styles.filterBtnActive : ''}`}
              onClick={() => setSignalFilter(s)}
            >
              {s === 'all' ? 'All' : s.toUpperCase()}
            </button>
          ))}
        </div>

        <div className={styles.filterGroup}>
          <span className={styles.filterLabel}>Sort</span>
          <select
            value={sortField}
            onChange={e => setSortField(e.target.value as SortField)}
            className={styles.sortSelect}
          >
            <option value="signal_score">Signal score</option>
            <option value="change_pct">Day change %</option>
            <option value="price">Price</option>
          </select>
        </div>
      </div>

      {/* ── Content ── */}
      {loading && <div className={styles.loading}>Loading assets…</div>}
      {error && <div className={styles.error}>Error: {error}</div>}

      {!loading && !error && (
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Asset</th>
                <th>Type</th>
                <th className={styles.right}>Price</th>
                <th className={styles.right}>Day change</th>
                <th>30-day</th>
                <th className={styles.right}>Volume</th>
                <th>Signal</th>
                <th className={styles.right}>Score</th>
              </tr>
            </thead>
            <tbody>
              {assets.length === 0 && (
                <tr>
                  <td colSpan={8} className={styles.empty}>
                    No assets match the current filters.
                  </td>
                </tr>
              )}
              {assets.map(asset => {
                const positive = (asset.change_pct ?? 0) >= 0
                return (
                  <tr key={asset.ticker}>
                    <td>
                      <div className={styles.assetCell}>
                        <span className={styles.ticker}>{asset.ticker}</span>
                        <span className={styles.name}>{asset.name}</span>
                      </div>
                    </td>
                    <td>
                      <span className={styles.typeBadge}>{asset.asset_type}</span>
                    </td>
                    <td className={styles.right}>
                      <span className={styles.price}>
                        {asset.has_real_price ? `$${fmt(asset.price)}` : '—'}
                      </span>
                    </td>
                    <td className={styles.right}>
                      <span className={positive ? styles.changeUp : styles.changeDown}>
                        {fmtChange(asset.change_pct)}
                      </span>
                    </td>
                    <td>
                      <Sparkline bars={asset.sparkline_bars} positive={positive} />
                    </td>
                    <td className={styles.right}>
                      <span className={styles.volume}>{fmtVol(asset.volume)}</span>
                    </td>
                    <td>
                      <SignalBadge signal={asset.signal} />
                    </td>
                    <td className={styles.right}>
                      <div className={styles.scoreWrap}>
                        <span className={styles.scoreNum}>{asset.signal_score}</span>
                        <div className={styles.scoreBar}>
                          <div
                            className={styles.scoreBarFill}
                            style={{ width: `${asset.signal_score}%` }}
                          />
                        </div>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
