/**
 * src/middleware.ts
 *
 * Next.js 16 Edge Middleware — runs before every request.
 *
 * Responsibilities:
 *   1. Refresh the Supabase session cookie on every server request
 *      (required by @supabase/ssr to keep sessions alive)
 *   2. Redirect unauthenticated users away from /dashboard/* to /auth/login
 *   3. Redirect authenticated users away from /auth/* to /dashboard
 *
 * This replaces the layout.tsx-only auth gate (which only ran on server
 * component render, not on direct URL navigation or API calls).
 *
 * Place this file at: src/middleware.ts
 * (Next.js auto-discovers middleware at src/middleware.ts or middleware.ts)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'

// Routes that require authentication
const PROTECTED_PREFIXES = ['/dashboard']

// Routes that authenticated users should be redirected away from
const AUTH_ROUTES = ['/auth/login', '/auth/signup']

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // ── Build a mutable response so we can write refreshed cookies ────────────
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  })

  // ── Initialise Supabase SSR client tied to this request/response ──────────
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          // Write cookies to both the request (for Server Components downstream)
          // and the response (sent back to the browser)
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          response = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // ── Refresh session — IMPORTANT: always call getUser() in middleware ───────
  // This call also refreshes the access token if it has expired using the
  // refresh token. Without this, sessions expire silently.
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const isAuthenticated = !!user

  // ── Route guards ──────────────────────────────────────────────────────────

  // 1. Unauthenticated user trying to access a protected route
  if (!isAuthenticated && PROTECTED_PREFIXES.some(p => pathname.startsWith(p))) {
    const loginUrl = request.nextUrl.clone()
    loginUrl.pathname = '/auth/login'
    // Preserve the originally requested URL so we can redirect back after login
    loginUrl.searchParams.set('next', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // 2. Authenticated user trying to access auth pages — redirect to dashboard
  if (isAuthenticated && AUTH_ROUTES.some(r => pathname === r)) {
    const dashUrl = request.nextUrl.clone()
    dashUrl.pathname = '/dashboard'
    dashUrl.search = '' // clear any query params
    return NextResponse.redirect(dashUrl)
  }

  // ── Pass through with refreshed session cookies ───────────────────────────
  return response
}

// ── Matcher — which paths this middleware runs on ────────────────────────────
//
// Exclude:
//   - _next/static  : static asset files
//   - _next/image   : Next.js image optimisation
//   - favicon.ico   : browser requests
//   - api/cron/*    : cron routes authenticate via CRON_SECRET header, not session
//   - api/          : all other API routes handle their own auth
//
// The middleware still refreshes the session on ALL matched routes, which is
// correct — it keeps the token alive on every page visit.

export const config = {
  matcher: [
    /*
     * Match all request paths EXCEPT:
     *   - _next/static (static files)
     *   - _next/image (image optimisation)
     *   - favicon.ico
     *   - api/ routes (they handle own auth)
     *   - public/ assets (images, icons etc.)
     */
    '/((?!_next/static|_next/image|favicon.ico|api/|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
