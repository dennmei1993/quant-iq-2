# Quant IQ — Phase 1 Implementation Guide

## What was built

Four interconnected features that make the platform use **real data** throughout:

| # | Feature | Files changed |
|---|---------|--------------|
| 1 | Polygon.io price + sparkline sync | `src/lib/polygon.ts` (new), `src/app/api/cron/ingest/route.ts` (updated) |
| 2 | Next.js middleware auth redirect | `src/middleware.ts` (new) |
| 3 | Auto-alert generation | `src/lib/alerts.ts` (new), `src/app/api/cron/ingest/route.ts` (updated) |
| 4 | Real portfolio risk scoring | `src/lib/risk.ts` (new), `src/app/api/portfolio/route.ts` (updated) |

Plus UI updates:
- `src/app/dashboard/assets/page.tsx` — real prices + SVG sparklines
- `src/app/dashboard/assets/assets.module.css` — styles
- `src/app/dashboard/portfolio/page.tsx` — risk gauge, per-holding event breakdown
- `src/app/dashboard/portfolio/portfolio.module.css` — styles

---

## Step 1 — Run the database migration

In your Supabase dashboard → SQL Editor, run:

```
supabase/migrations/002_phase1_real_data.sql
```

This adds:
- `price`, `open`, `high`, `low`, `change`, `change_pct`, `volume`, `sparkline_bars`, `price_updated_at` to `asset_signals`
- `event_id`, `theme_id`, `severity`, `sentiment`, `alert_type`, `title`, `message` to `alerts`
- `url` (unique, for deduplication) to `events`
- `name`, `asset_type`, `notes` to `holdings`

---

## Step 2 — Add POLYGON_API_KEY to Vercel

In Vercel dashboard → your project → Settings → Environment Variables:

```
POLYGON_API_KEY = your_key_here
```

Get your key at: https://polygon.io — the **free tier** is sufficient for MVP.

**Free tier limits:**
- 5 API calls / minute
- Previous close endpoint: available ✓
- Daily OHLC aggregates (sparklines): available ✓
- Real-time quotes: NOT available (we use prev close — fine for daily cron)

The ingest cron uses `fetchPricesForTickers` which batches in groups of 5 with a 13-second
pause between batches. For 23 assets that's ~5 batches → ~52 seconds of total wait time.
This is expected — Vercel cron functions have a 60s default timeout on Hobby plan.

> **Upgrade tip:** On Vercel Pro or if you upgrade the Polygon plan, remove the `sleep`
> in `lib/polygon.ts` to eliminate the wait entirely.

---

## Step 3 — Copy new files into your project

Place files according to this mapping:

```
quant-iq-phase1/
├── src/
│   ├── middleware.ts                           → src/middleware.ts         (NEW)
│   ├── lib/
│   │   ├── polygon.ts                          → src/lib/polygon.ts        (NEW)
│   │   ├── alerts.ts                           → src/lib/alerts.ts         (NEW)
│   │   └── risk.ts                             → src/lib/risk.ts           (NEW)
│   └── app/
│       ├── api/
│       │   ├── cron/ingest/route.ts            → REPLACE existing file     (UPDATED)
│       │   ├── assets/route.ts                 → REPLACE existing file     (UPDATED)
│       │   └── portfolio/route.ts              → REPLACE existing file     (UPDATED)
│       └── dashboard/
│           ├── assets/
│           │   ├── page.tsx                    → REPLACE existing file     (UPDATED)
│           │   └── assets.module.css           → REPLACE existing file     (NEW/UPDATED)
│           └── portfolio/
│               ├── page.tsx                    → REPLACE existing file     (UPDATED)
│               └── portfolio.module.css        → REPLACE existing file     (NEW/UPDATED)
└── supabase/migrations/
    └── 002_phase1_real_data.sql                → run in Supabase SQL editor
```

---

## Step 4 — Remove the old layout.tsx auth gate (optional cleanup)

The new `middleware.ts` handles auth redirects for all dashboard routes. The existing
`src/app/dashboard/layout.tsx` may still have a manual auth check like:

```typescript
// Old pattern — can be simplified now middleware handles the redirect
const { data: { user } } = await supabase.auth.getUser()
if (!user) redirect('/auth/login')
```

You can **keep this as a defence-in-depth layer** (no harm in double-checking), or
remove the redirect — the middleware will catch it first. Keep the `DashboardShell`
rendering logic as-is.

---

## Step 5 — Deploy and trigger cron manually

After deploying, trigger the ingest cron manually to populate prices immediately
(rather than waiting until 8am UTC):

```bash
curl -H "Authorization: Bearer YOUR_CRON_SECRET" \
  https://your-app.vercel.app/api/cron/ingest
```

Check the response JSON — you should see:
```json
{
  "status": "ok",
  "log": [
    "Starting news ingest...",
    "Fetched 20 raw events from NewsAPI",
    "Events: 18 classified, 2 deduplicated/skipped",
    "Starting Polygon.io price sync...",
    "Fetching prices for 23 tickers: AAPL, MSFT, ...",
    "Got prices for 23 / 23 tickers",
    "Got sparklines for 23 / 23 tickers",
    "Upserted 23 rows into asset_signals",
    "Starting auto-alert generation...",
    "Created 4 new alerts across all users"
  ],
  "errors": []
}
```

If Polygon returns 0 prices, check `POLYGON_API_KEY` is set correctly.

---

## How each feature works

### 1. Polygon price sync

**Flow:** `cron/ingest` → `lib/polygon.fetchPricesForTickers()` → Polygon `/v2/aggs/ticker/{ticker}/prev` → `asset_signals` upsert

The signal (`buy`/`watch`/`hold`/`avoid`) and signal_score (0–100) are currently derived
purely from the day's % price change. This is intentionally simple for Phase 1.

**Phase 2 enhancement:** combine the price signal with the `sentiment_score` from recent
events that match that ticker — events already contain `tickers[]` so the join is trivial.

### 2. Middleware auth

**Flow:** Browser request → `middleware.ts` → Supabase session refresh → redirect or pass through

Key behaviour:
- Unauthenticated `/dashboard/*` → redirect to `/auth/login?next=/dashboard/...`
- Authenticated `/auth/login` or `/auth/signup` → redirect to `/dashboard`
- All API routes are excluded from the matcher (they handle their own auth)
- The `?next=` param is preserved so after login you can redirect the user back to where they were going

To use `?next=` in your login page, read it from `searchParams` and redirect there after
successful `supabase.auth.signInWithPassword()`.

### 3. Auto-alert generation

**Flow:** `cron/ingest` → `lib/alerts.generateAlertsForAllUsers()` → match events to holdings → insert `alerts` rows

Three alert types:
- `portfolio_risk` — an event directly names a ticker the user holds
- `macro_shift` — a high-impact event affects a sector the user has exposure to
- `theme_update` — an active investment theme lists a held ticker as a candidate

De-duplication prevents duplicate alerts: one `(user_id, event_id)` and one `(user_id, theme_id)` per alert.

### 4. Portfolio risk scoring

**Flow:** `GET /api/portfolio` → `lib/risk.computePortfolioRisk()` → join holdings × events → weighted score per holding → portfolio aggregate

Scoring formula per holding:
```
risk_contribution = ((1 - sentiment_score) / 2) × 100   // bearish → high risk
event_weight = impact_weight × recency_decay             // high-impact recent events weighted more
holding_score = Σ(risk_contribution × event_weight) / Σ(event_weight)
```

Recency decay: `exp(-0.2 × age_days)` — today's events score at 1.0, 7-day-old at ~0.25.

Portfolio score = equal-weight average across all holdings (Phase 2 can weight by $ value).

---

## Environment variables — complete list for Phase 1

```
NEXT_PUBLIC_SUPABASE_URL          = https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY     = eyJ...
SUPABASE_SERVICE_ROLE_KEY         = eyJ...  (server only)
ANTHROPIC_API_KEY                 = sk-ant-...
NEWSAPI_KEY                       = ...
POLYGON_API_KEY                   = ...     ← NEW for Phase 1
NEXT_PUBLIC_APP_URL               = https://your-app.vercel.app
CRON_SECRET                       = (32+ char random string)
```

---

## Vercel cron timeout consideration

The ingest cron now does more work:
1. News fetch + Claude classification: ~30–60s (existing)
2. Polygon price fetch (23 tickers): ~52s on free tier (4 batches × 13s)
3. Polygon sparkline fetch: ~52s on free tier

**Total: up to ~2.5 minutes**

Vercel Hobby plan has a **10-second** function timeout by default for API routes,
but **cron jobs run as background functions with up to 300 seconds** (5 minutes).

To confirm your cron has extended timeout, add to `vercel.json`:

```json
{
  "crons": [
    { "path": "/api/cron/ingest", "schedule": "0 8 * * *" },
    { "path": "/api/cron/themes", "schedule": "0 9 * * *" }
  ],
  "functions": {
    "src/app/api/cron/ingest/route.ts": {
      "maxDuration": 300
    }
  }
}
```

---

## Known limitations (Phase 2 work)

1. **Signal score is price-only** — not yet combined with event sentiment for that ticker
2. **Crypto tickers** — Polygon crypto uses `X:BTCUSD` format; we map BTC/ETH/SOL but
   other crypto assets need entries added to `CRYPTO_MAP` in `lib/polygon.ts`
3. **Commodities** — Polygon free tier may not cover all commodity tickers; check coverage
4. **`?next=` redirect** — the login page needs to read and use the `next` param
5. **Portfolio $ weighting** — risk score uses equal weighting; richer would weight by position value
