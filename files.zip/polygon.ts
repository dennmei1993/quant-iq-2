/**
 * lib/polygon.ts
 * Polygon.io REST API helpers for real asset prices + sparkline OHLC data.
 *
 * Free tier limits:
 *   - 5 API calls / minute
 *   - Previous close & aggregates (daily OHLC) available
 *   - Real-time quote NOT available on free tier → we use prev close
 *
 * Usage in cron:
 *   import { fetchPricesForTickers } from '@/lib/polygon'
 *   const prices = await fetchPricesForTickers(['AAPL','MSFT','SPY'])
 */

const BASE = 'https://api.polygon.io'

// ─── Types ──────────────────────────────────────────────────────────────────

export interface TickerPrice {
  ticker: string
  price: number          // previous close
  open: number
  high: number
  low: number
  change: number         // $ change vs prior close
  change_pct: number     // % change vs prior close
  volume: number
  updated_at: string     // ISO timestamp of the trading day
}

export interface SparklineBar {
  t: number   // Unix ms timestamp
  o: number
  h: number
  l: number
  c: number
  v: number
}

export interface TickerSparkline {
  ticker: string
  bars: SparklineBar[]   // 30 daily bars
}

// ─── Helpers ────────────────────────────────────────────────────────────────

function polygonKey(): string {
  const key = process.env.POLYGON_API_KEY
  if (!key) throw new Error('POLYGON_API_KEY is not set')
  return key
}

/** ISO date string YYYY-MM-DD, offset by `daysAgo` from today */
function isoDate(daysAgo = 0): string {
  const d = new Date()
  d.setDate(d.getDate() - daysAgo)
  return d.toISOString().slice(0, 10)
}

/**
 * Sleep helper — Polygon free tier is 5 req/min.
 * We insert a 13-second delay between batches of 5 tickers to stay safe.
 */
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms))

// ─── Previous Close (single ticker) ─────────────────────────────────────────

async function fetchPrevClose(ticker: string): Promise<TickerPrice | null> {
  const key = polygonKey()
  const url = `${BASE}/v2/aggs/ticker/${ticker}/prev?adjusted=true&apiKey=${key}`

  try {
    const res = await fetch(url, { next: { revalidate: 0 } })
    if (!res.ok) {
      console.error(`[polygon] prev close ${ticker} → HTTP ${res.status}`)
      return null
    }
    const json = await res.json()
    if (json.resultsCount === 0 || !json.results?.length) return null

    const r = json.results[0]
    const change = r.c - r.o
    const change_pct = r.o > 0 ? (change / r.o) * 100 : 0

    return {
      ticker,
      price: r.c,
      open: r.o,
      high: r.h,
      low: r.l,
      change: parseFloat(change.toFixed(4)),
      change_pct: parseFloat(change_pct.toFixed(4)),
      volume: r.v,
      updated_at: new Date(r.t).toISOString(),
    }
  } catch (err) {
    console.error(`[polygon] prev close ${ticker} error:`, err)
    return null
  }
}

// ─── 30-day Sparkline (single ticker) ───────────────────────────────────────

async function fetchSparkline(ticker: string): Promise<TickerSparkline | null> {
  const key = polygonKey()
  const to = isoDate(1)    // yesterday (last closed session)
  const from = isoDate(44) // ~30 trading days back (44 calendar days covers weekends/holidays)

  const url =
    `${BASE}/v2/aggs/ticker/${ticker}/range/1/day/${from}/${to}` +
    `?adjusted=true&sort=asc&limit=30&apiKey=${key}`

  try {
    const res = await fetch(url, { next: { revalidate: 0 } })
    if (!res.ok) {
      console.error(`[polygon] sparkline ${ticker} → HTTP ${res.status}`)
      return null
    }
    const json = await res.json()
    if (!json.results?.length) return null

    // Trim to last 30 bars
    const bars: SparklineBar[] = json.results.slice(-30).map((r: any) => ({
      t: r.t,
      o: r.o,
      h: r.h,
      l: r.l,
      c: r.c,
      v: r.v,
    }))

    return { ticker, bars }
  } catch (err) {
    console.error(`[polygon] sparkline ${ticker} error:`, err)
    return null
  }
}

// ─── Crypto via Polygon (uses X:BTCUSD format) ───────────────────────────────

/**
 * Map our internal crypto tickers to Polygon forex-style pairs.
 * Polygon free tier supports crypto daily aggregates.
 */
const CRYPTO_MAP: Record<string, string> = {
  BTC: 'X:BTCUSD',
  ETH: 'X:ETHUSD',
  SOL: 'X:SOLUSD',
}

function toPolygonTicker(ticker: string): string {
  return CRYPTO_MAP[ticker] ?? ticker
}

// ─── Batch fetch (rate-limit aware) ─────────────────────────────────────────

/**
 * Fetch previous-close prices for an array of tickers.
 * Processes in batches of 5 with a 13-second pause between batches
 * to respect Polygon free tier (5 req/min).
 *
 * For production Pro tier, remove the sleep entirely.
 */
export async function fetchPricesForTickers(
  tickers: string[]
): Promise<Map<string, TickerPrice>> {
  const result = new Map<string, TickerPrice>()
  const BATCH = 5
  const DELAY_MS = 13_000 // 13s between batches on free tier

  for (let i = 0; i < tickers.length; i += BATCH) {
    const batch = tickers.slice(i, i + BATCH)

    await Promise.all(
      batch.map(async (t) => {
        const polyTicker = toPolygonTicker(t)
        const price = await fetchPrevClose(polyTicker)
        if (price) {
          // Store under the original ticker key, not the polygon X: format
          result.set(t, { ...price, ticker: t })
        }
      })
    )

    // Pause between batches (except after the last one)
    if (i + BATCH < tickers.length) {
      console.log(`[polygon] batch ${i / BATCH + 1} done — waiting ${DELAY_MS / 1000}s`)
      await sleep(DELAY_MS)
    }
  }

  return result
}

/**
 * Fetch 30-day sparkline bars for an array of tickers.
 * Same rate-limit batching as fetchPricesForTickers.
 */
export async function fetchSparklinesForTickers(
  tickers: string[]
): Promise<Map<string, SparklineBar[]>> {
  const result = new Map<string, SparklineBar[]>()
  const BATCH = 5
  const DELAY_MS = 13_000

  for (let i = 0; i < tickers.length; i += BATCH) {
    const batch = tickers.slice(i, i + BATCH)

    await Promise.all(
      batch.map(async (t) => {
        const polyTicker = toPolygonTicker(t)
        const sparkline = await fetchSparkline(polyTicker)
        if (sparkline) {
          result.set(t, sparkline.bars)
        }
      })
    )

    if (i + BATCH < tickers.length) {
      console.log(`[polygon] sparkline batch ${i / BATCH + 1} done — waiting ${DELAY_MS / 1000}s`)
      await sleep(DELAY_MS)
    }
  }

  return result
}
