/**
 * app/dashboard/portfolio/page.tsx
 *
 * Portfolio page — shows holdings enriched with:
 *  - Real prices from asset_signals (Polygon.io)
 *  - Event-based risk score per holding (from lib/risk.ts)
 *  - AI advisory memo trigger
 *  - Portfolio-level risk score + breakdown
 */

'use client'

import { useEffect, useState, useCallback } from 'react'
import styles from './portfolio.module.css'

// ─── Types ───────────────────────────────────────────────────────────────────

interface TopEvent {
  id: string
  headline: string
  ai_summary: string | null
  sentiment_score: number
  impact_level: string | null
  published_at: string
}

interface Holding {
  id: string
  ticker: string
  name: string
  asset_type: string
  quantity: number | null
  avg_cost: number | null
  price: number | null
  change: number | null
  change_pct: number | null
  signal: 'buy' | 'watch' | 'hold' | 'avoid' | null
  signal_score: number | null
  risk_score: number | null
  risk_label: 'low' | 'moderate' | 'elevated' | 'high' | null
  event_count: number
  top_event: TopEvent | null
}

interface Portfolio {
  id: string
  name: string
  holdings: Holding[]
}

interface RiskSummary {
  score: number
  label: string
  event_coverage: number
  computed_at: string
}

// ─── Risk score gauge ─────────────────────────────────────────────────────────

function RiskGauge({ score, label }: { score: number; label: string }) {
  const colors: Record<string, string> = {
    low: '#1D9E75',
    moderate: '#c8a96e',
    elevated: '#e09845',
    high: '#E24B4A',
  }
  const color = colors[label] ?? colors.moderate

  return (
    <div className={styles.gauge}>
      <svg width="80" height="80" viewBox="0 0 80 80">
        {/* Track */}
        <circle
          cx="40" cy="40" r="30"
          fill="none"
          stroke="rgba(15,28,46,0.07)"
          strokeWidth="7"
        />
        {/* Fill — score as arc (circumference = 2π×30 ≈ 188.5) */}
        <circle
          cx="40" cy="40" r="30"
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${(score / 100) * 188.5} 188.5`}
          transform="rotate(-90 40 40)"
          style={{ transition: 'stroke-dasharray 0.5s' }}
        />
        {/* Score number */}
        <text x="40" y="38" textAnchor="middle" fontSize="16" fontWeight="600" fill={color} fontFamily="DM Mono, monospace">
          {score}
        </text>
        <text x="40" y="52" textAnchor="middle" fontSize="8" fill="rgba(15,28,46,0.4)" fontFamily="DM Sans, sans-serif" textTransform="uppercase">
          {label}
        </text>
      </svg>
    </div>
  )
}

// ─── Risk label badge ──────────────────────────────────────────────────────────

function RiskBadge({ label }: { label: Holding['risk_label'] }) {
  if (!label) return <span className={styles.noRisk}>—</span>
  const map = {
    low:      { cls: styles.riskLow,      text: 'Low risk' },
    moderate: { cls: styles.riskModerate, text: 'Moderate' },
    elevated: { cls: styles.riskElevated, text: 'Elevated' },
    high:     { cls: styles.riskHigh,     text: 'High risk' },
  }
  return <span className={`${styles.riskBadge} ${map[label].cls}`}>{map[label].text}</span>
}

// ─── Add holding form ─────────────────────────────────────────────────────────

function AddHoldingForm({ portfolioId, onAdded }: { portfolioId: string; onAdded: () => void }) {
  const [ticker, setTicker] = useState('')
  const [quantity, setQuantity] = useState('')
  const [avgCost, setAvgCost] = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!ticker.trim()) return
    setLoading(true)
    setErr(null)
    try {
      const res = await fetch('/api/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticker: ticker.trim().toUpperCase(),
          quantity: quantity ? parseFloat(quantity) : undefined,
          avg_cost: avgCost ? parseFloat(avgCost) : undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`)
      setTicker('')
      setQuantity('')
      setAvgCost('')
      onAdded()
    } catch (e: any) {
      setErr(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form className={styles.addForm} onSubmit={submit}>
      <input
        className={styles.addInput}
        placeholder="Ticker (e.g. AAPL)"
        value={ticker}
        onChange={e => setTicker(e.target.value)}
        maxLength={10}
      />
      <input
        className={styles.addInput}
        placeholder="Quantity (optional)"
        type="number"
        min="0"
        step="any"
        value={quantity}
        onChange={e => setQuantity(e.target.value)}
      />
      <input
        className={styles.addInput}
        placeholder="Avg cost USD (optional)"
        type="number"
        min="0"
        step="any"
        value={avgCost}
        onChange={e => setAvgCost(e.target.value)}
      />
      <button className={styles.addBtn} type="submit" disabled={loading || !ticker.trim()}>
        {loading ? 'Adding…' : '+ Add'}
      </button>
      {err && <span className={styles.addErr}>{err}</span>}
    </form>
  )
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function PortfolioPage() {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null)
  const [risk, setRisk] = useState<RiskSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [removingId, setRemovingId] = useState<string | null>(null)
  const [memoLoading, setMemoLoading] = useState(false)
  const [memoText, setMemoText] = useState<string | null>(null)
  const [expandedEvent, setExpandedEvent] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/portfolio')
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setPortfolio(data.portfolio)
      setRisk(data.risk)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function removeHolding(holdingId: string) {
    setRemovingId(holdingId)
    await fetch(`/api/portfolio?holding_id=${holdingId}`, { method: 'DELETE' })
    setRemovingId(null)
    load()
  }

  async function generateMemo() {
    if (!portfolio) return
    setMemoLoading(true)
    setMemoText(null)
    try {
      const res = await fetch('/api/advisory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ portfolio_id: portfolio.id }),
      })
      const data = await res.json()
      setMemoText(data.memo?.content ?? 'No memo generated.')
    } catch {
      setMemoText('Failed to generate memo. Please try again.')
    } finally {
      setMemoLoading(false)
    }
  }

  const fmt = (n: number | null, decimals = 2) =>
    n == null ? '—' : `$${n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`

  const fmtChange = (n: number | null) =>
    n == null ? '—' : `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`

  const holdings = portfolio?.holdings ?? []

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Portfolio</h1>
          <p className={styles.sub}>
            {holdings.length === 0
              ? 'Add holdings below to start tracking event impact'
              : `${holdings.length} holding${holdings.length === 1 ? '' : 's'} · risk scored against last 7 days of events`}
          </p>
        </div>

        {risk && holdings.length > 0 && (
          <div className={styles.riskSummary}>
            <RiskGauge score={risk.score} label={risk.label} />
            <div className={styles.riskMeta}>
              <span className={styles.riskMetaLabel}>Portfolio risk</span>
              <span className={styles.riskMetaVal}>
                {risk.event_coverage}% of holdings have event data
              </span>
              <span className={styles.riskMetaTime}>
                Updated {new Date(risk.computed_at).toLocaleTimeString()}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* ── Add holding ── */}
      {portfolio && (
        <AddHoldingForm portfolioId={portfolio.id} onAdded={load} />
      )}

      {/* ── States ── */}
      {loading && <div className={styles.loading}>Loading portfolio…</div>}
      {error && <div className={styles.error}>{error}</div>}

      {/* ── Holdings table ── */}
      {!loading && !error && holdings.length > 0 && (
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Holding</th>
                <th className={styles.right}>Price</th>
                <th className={styles.right}>Change</th>
                <th>Signal</th>
                <th>Risk</th>
                <th>Top event</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {holdings.map(h => (
                <>
                  <tr key={h.id} className={styles.holdingRow}>
                    <td>
                      <div className={styles.holdingCell}>
                        <span className={styles.holdTicker}>{h.ticker}</span>
                        {h.quantity != null && (
                          <span className={styles.holdQty}>{h.quantity} units</span>
                        )}
                        {h.avg_cost != null && (
                          <span className={styles.holdCost}>avg {fmt(h.avg_cost)}</span>
                        )}
                      </div>
                    </td>
                    <td className={styles.right}>
                      <span className={styles.price}>{fmt(h.price)}</span>
                    </td>
                    <td className={styles.right}>
                      <span className={(h.change_pct ?? 0) >= 0 ? styles.changeUp : styles.changeDown}>
                        {fmtChange(h.change_pct)}
                      </span>
                    </td>
                    <td>
                      {h.signal ? (
                        <span className={`${styles.sigBadge} ${styles[`sig_${h.signal}`]}`}>
                          {h.signal.toUpperCase()}
                        </span>
                      ) : '—'}
                    </td>
                    <td>
                      <div className={styles.riskCell}>
                        <RiskBadge label={h.risk_label} />
                        {h.risk_score != null && (
                          <span className={styles.riskScore}>{h.risk_score}</span>
                        )}
                      </div>
                    </td>
                    <td>
                      {h.top_event ? (
                        <button
                          className={styles.eventToggle}
                          onClick={() => setExpandedEvent(expandedEvent === h.id ? null : h.id)}
                        >
                          {h.event_count} event{h.event_count !== 1 ? 's' : ''} ↓
                        </button>
                      ) : (
                        <span className={styles.noEvent}>No recent events</span>
                      )}
                    </td>
                    <td>
                      <button
                        className={styles.removeBtn}
                        onClick={() => removeHolding(h.id)}
                        disabled={removingId === h.id}
                        aria-label={`Remove ${h.ticker}`}
                      >
                        {removingId === h.id ? '…' : '×'}
                      </button>
                    </td>
                  </tr>
                  {/* Expanded event row */}
                  {expandedEvent === h.id && h.top_event && (
                    <tr key={`${h.id}-event`} className={styles.eventRow}>
                      <td colSpan={7}>
                        <div className={styles.eventCard}>
                          <div className={styles.eventMeta}>
                            <span className={
                              h.top_event.impact_level === 'high'
                                ? styles.impactHigh
                                : styles.impactMed
                            }>
                              {h.top_event.impact_level?.toUpperCase()} IMPACT
                            </span>
                            <span className={styles.eventDate}>
                              {new Date(h.top_event.published_at).toLocaleDateString()}
                            </span>
                            <span className={
                              h.top_event.sentiment_score > 0.2
                                ? styles.sentBull
                                : h.top_event.sentiment_score < -0.2
                                  ? styles.sentBear
                                  : styles.sentNeut
                            }>
                              Sentiment: {(h.top_event.sentiment_score * 100).toFixed(0)}
                            </span>
                          </div>
                          <p className={styles.eventHeadline}>{h.top_event.headline}</p>
                          {h.top_event.ai_summary && (
                            <p className={styles.eventSummary}>{h.top_event.ai_summary}</p>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {!loading && !error && holdings.length === 0 && (
        <div className={styles.empty}>
          No holdings yet. Add a ticker above to begin tracking impact.
        </div>
      )}

      {/* ── AI Advisory memo ── */}
      {holdings.length > 0 && (
        <div className={styles.memoSection}>
          <div className={styles.memoHeader}>
            <div>
              <h3 className={styles.memoTitle}>AI Advisory Memo</h3>
              <p className={styles.memoSub}>
                Claude analyses your holdings against recent events and generates a personalised brief.
              </p>
            </div>
            <button
              className={styles.memoBtn}
              onClick={generateMemo}
              disabled={memoLoading}
            >
              {memoLoading ? 'Generating…' : 'Generate memo'}
            </button>
          </div>
          {memoText && (
            <div className={styles.memoContent}>{memoText}</div>
          )}
        </div>
      )}
    </div>
  )
}
