/**
 * app/api/assets/route.ts
 *
 * GET /api/assets
 *
 * Returns assets enriched with real price data from the asset_signals table
 * (populated daily by the Polygon.io sync in the ingest cron).
 *
 * Query params:
 *   type   : stock | etf | crypto | commodity  (filter)
 *   signal : buy | watch | hold | avoid        (filter)
 *   sort   : signal_score | change_pct | price (default: signal_score desc)
 *
 * Auth: requires valid Supabase session cookie.
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

const VALID_TYPES = ['stock', 'etf', 'crypto', 'commodity'] as const
const VALID_SIGNALS = ['buy', 'watch', 'hold', 'avoid'] as const
const VALID_SORTS = ['signal_score', 'change_pct', 'price'] as const

type AssetType = (typeof VALID_TYPES)[number]
type SignalType = (typeof VALID_SIGNALS)[number]
type SortType = (typeof VALID_SORTS)[number]

export async function GET(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  // Parse + validate query params
  const params = req.nextUrl.searchParams
  const typeParam = params.get('type') as AssetType | null
  const signalParam = params.get('signal') as SignalType | null
  const sortParam = (params.get('sort') ?? 'signal_score') as SortType

  if (typeParam && !VALID_TYPES.includes(typeParam)) {
    return NextResponse.json({ error: 'Invalid type param' }, { status: 400 })
  }
  if (signalParam && !VALID_SIGNALS.includes(signalParam)) {
    return NextResponse.json({ error: 'Invalid signal param' }, { status: 400 })
  }
  if (!VALID_SORTS.includes(sortParam)) {
    return NextResponse.json({ error: 'Invalid sort param' }, { status: 400 })
  }

  // 1. Fetch assets (with optional type filter)
  let assetsQuery = supabase
    .from('assets')
    .select('ticker, name, asset_type, sector')

  if (typeParam) {
    assetsQuery = assetsQuery.eq('asset_type', typeParam)
  }

  const { data: assets, error: assetErr } = await assetsQuery

  if (assetErr) {
    return NextResponse.json({ error: assetErr.message }, { status: 500 })
  }
  if (!assets?.length) {
    return NextResponse.json({ assets: [] })
  }

  // 2. Fetch latest signals for all returned tickers
  const tickers = assets.map(a => a.ticker)

  let signalsQuery = supabase
    .from('asset_signals')
    .select(`
      ticker,
      price,
      open,
      high,
      low,
      change,
      change_pct,
      volume,
      sparkline_bars,
      signal,
      signal_score,
      price_updated_at,
      updated_at
    `)
    .in('ticker', tickers)

  // Signal filter (applied on asset_signals, not assets)
  if (signalParam) {
    signalsQuery = signalsQuery.eq('signal', signalParam)
  }

  const { data: signals, error: signalErr } = await signalsQuery

  if (signalErr) {
    return NextResponse.json({ error: signalErr.message }, { status: 500 })
  }

  // Build a lookup map
  const signalMap = new Map<string, any>()
  for (const s of signals ?? []) {
    signalMap.set(s.ticker, s)
  }

  // 3. Merge assets + signals, filter if signal param is set
  let enriched = assets
    .map(asset => {
      const sig = signalMap.get(asset.ticker)
      return {
        ticker: asset.ticker,
        name: asset.name ?? asset.ticker,
        asset_type: asset.asset_type,
        sector: asset.sector ?? null,
        // Price data — null if not yet synced from Polygon
        price: sig?.price ?? null,
        open: sig?.open ?? null,
        high: sig?.high ?? null,
        low: sig?.low ?? null,
        change: sig?.change ?? null,
        change_pct: sig?.change_pct ?? null,
        volume: sig?.volume ?? null,
        // Sparkline — array of {t,o,h,l,c,v} or empty
        sparkline_bars: sig?.sparkline_bars ?? [],
        // Signal
        signal: sig?.signal ?? 'hold',
        signal_score: sig?.signal_score ?? 50,
        // Timestamps
        price_updated_at: sig?.price_updated_at ?? null,
        last_sync: sig?.updated_at ?? null,
        has_real_price: !!sig?.price,
      }
    })
    // If a signal filter is active, drop assets with no signal data
    .filter(a => !signalParam || (signalParam && a.signal === signalParam))

  // 4. Sort
  enriched.sort((a, b) => {
    switch (sortParam) {
      case 'signal_score':
        return (b.signal_score ?? 0) - (a.signal_score ?? 0)
      case 'change_pct':
        return (b.change_pct ?? 0) - (a.change_pct ?? 0)
      case 'price':
        return (b.price ?? 0) - (a.price ?? 0)
      default:
        return 0
    }
  })

  return NextResponse.json({
    assets: enriched,
    meta: {
      total: enriched.length,
      with_real_prices: enriched.filter(a => a.has_real_price).length,
      last_sync: signals?.[0]?.updated_at ?? null,
    },
  })
}
