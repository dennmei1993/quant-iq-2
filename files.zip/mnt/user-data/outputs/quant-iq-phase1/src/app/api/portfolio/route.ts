/**
 * app/api/portfolio/route.ts
 *
 * GET  /api/portfolio          — fetch portfolio + holdings + real risk score
 * POST /api/portfolio          — add a holding
 * DELETE /api/portfolio        — remove a holding (?holding_id=)
 *
 * All routes require a valid Supabase session cookie.
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { computePortfolioRisk } from '@/lib/risk'
import { z } from 'zod'

// ─── GET ─────────────────────────────────────────────────────────────────────

export async function GET() {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  // Load or create portfolio
  let { data: portfolio, error: portErr } = await supabase
    .from('portfolios')
    .select('id, name, created_at')
    .eq('user_id', user.id)
    .maybeSingle()

  if (portErr) {
    return NextResponse.json({ error: portErr.message }, { status: 500 })
  }

  // Auto-create portfolio if none exists
  if (!portfolio) {
    const { data: newPort, error: createErr } = await supabase
      .from('portfolios')
      .insert({ user_id: user.id, name: 'My Portfolio' })
      .select('id, name, created_at')
      .single()

    if (createErr || !newPort) {
      return NextResponse.json({ error: 'Failed to create portfolio' }, { status: 500 })
    }
    portfolio = newPort
  }

  // Load holdings
  const { data: holdings, error: holdErr } = await supabase
    .from('holdings')
    .select('id, ticker, quantity, avg_cost, notes, created_at')
    .eq('portfolio_id', portfolio.id)
    .order('created_at', { ascending: false })

  if (holdErr) {
    return NextResponse.json({ error: holdErr.message }, { status: 500 })
  }

  // Load current asset signals for held tickers (prices + signals)
  const tickers = (holdings ?? []).map(h => h.ticker)
  let assetSignals: Record<string, any> = {}

  if (tickers.length > 0) {
    const { data: signals } = await supabase
      .from('asset_signals')
      .select('ticker, price, change, change_pct, signal, signal_score, sparkline_bars, price_updated_at')
      .in('ticker', tickers)

    for (const s of signals ?? []) {
      assetSignals[s.ticker] = s
    }
  }

  // Compute real risk score
  let riskData = null
  if (holdings && holdings.length > 0) {
    try {
      riskData = await computePortfolioRisk(supabase, portfolio.id)
    } catch (err) {
      // Non-fatal — return portfolio without risk score rather than 500
      console.error('[portfolio GET] risk computation failed:', err)
    }
  }

  // Merge signal + risk data into each holding
  const enrichedHoldings = (holdings ?? []).map(h => {
    const signal = assetSignals[h.ticker] ?? null
    const holdingRisk = riskData?.holdings.find(r => r.ticker === h.ticker.toUpperCase())

    return {
      ...h,
      // Price data from asset_signals
      price: signal?.price ?? null,
      change: signal?.change ?? null,
      change_pct: signal?.change_pct ?? null,
      signal: signal?.signal ?? null,
      signal_score: signal?.signal_score ?? null,
      sparkline_bars: signal?.sparkline_bars ?? [],
      price_updated_at: signal?.price_updated_at ?? null,
      // Risk data computed from events
      risk_score: holdingRisk?.risk_score ?? null,
      risk_label: holdingRisk?.risk_label ?? null,
      event_count: holdingRisk?.event_count ?? 0,
      top_event: holdingRisk?.top_event ?? null,
    }
  })

  return NextResponse.json({
    portfolio: {
      ...portfolio,
      holdings: enrichedHoldings,
    },
    risk: riskData
      ? {
          score: riskData.risk_score,
          label: riskData.risk_label,
          event_coverage: riskData.event_coverage,
          computed_at: riskData.computed_at,
        }
      : null,
  })
}

// ─── POST ─────────────────────────────────────────────────────────────────────

const AddHoldingSchema = z.object({
  ticker: z.string().min(1).max(10).toUpperCase(),
  name: z.string().max(100).optional(),
  asset_type: z.enum(['stock', 'etf', 'crypto', 'commodity']).optional(),
  quantity: z.number().positive().optional(),
  avg_cost: z.number().positive().optional(),
  notes: z.string().max(500).optional(),
})

export async function POST(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  const parsed = AddHoldingSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 })
  }

  const { ticker, name, asset_type, quantity, avg_cost, notes } = parsed.data

  // Get or create portfolio
  let { data: portfolio } = await supabase
    .from('portfolios')
    .select('id')
    .eq('user_id', user.id)
    .maybeSingle()

  if (!portfolio) {
    const { data: newPort } = await supabase
      .from('portfolios')
      .insert({ user_id: user.id, name: 'My Portfolio' })
      .select('id')
      .single()
    portfolio = newPort
  }

  if (!portfolio) {
    return NextResponse.json({ error: 'Could not resolve portfolio' }, { status: 500 })
  }

  // Check for duplicate ticker in this portfolio
  const { data: existing } = await supabase
    .from('holdings')
    .select('id')
    .eq('portfolio_id', portfolio.id)
    .eq('ticker', ticker)
    .maybeSingle()

  if (existing) {
    return NextResponse.json(
      { error: `${ticker} is already in your portfolio` },
      { status: 409 }
    )
  }

  const { data: holding, error: insertErr } = await supabase
    .from('holdings')
    .insert({
      portfolio_id: portfolio.id,
      ticker,
      name: name ?? ticker,
      asset_type: asset_type ?? 'stock',
      quantity: quantity ?? null,
      avg_cost: avg_cost ?? null,
      notes: notes ?? null,
    })
    .select()
    .single()

  if (insertErr) {
    return NextResponse.json({ error: insertErr.message }, { status: 500 })
  }

  return NextResponse.json({ holding }, { status: 201 })
}

// ─── DELETE ───────────────────────────────────────────────────────────────────

export async function DELETE(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const holdingId = req.nextUrl.searchParams.get('holding_id')
  if (!holdingId) {
    return NextResponse.json({ error: 'holding_id is required' }, { status: 400 })
  }

  // RLS ensures user can only delete holdings in their own portfolio
  const { error: deleteErr } = await supabase
    .from('holdings')
    .delete()
    .eq('id', holdingId)

  if (deleteErr) {
    return NextResponse.json({ error: deleteErr.message }, { status: 500 })
  }

  return NextResponse.json({ deleted: true })
}
