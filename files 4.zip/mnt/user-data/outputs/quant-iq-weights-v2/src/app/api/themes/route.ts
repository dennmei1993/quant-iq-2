/**
 * app/api/themes/route.ts
 *
 * GET /api/themes
 *
 * Returns active themes with their ticker weights.
 *
 * Query params:
 *   timeframe : 1m | 3m | 6m  (optional filter)
 *   ticker    : e.g. NVDA     (returns only themes that include this ticker)
 *   weights   : false         (omit ticker_weights for lighter responses)
 *
 * Auth: requires valid Supabase session cookie.
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const supabase = await createClient()

  const { data: { user }, error: authErr } = await supabase.auth.getUser()
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const params      = req.nextUrl.searchParams
  const timeframe   = params.get('timeframe')
  const ticker      = params.get('ticker')?.toUpperCase()
  const withWeights = params.get('weights') !== 'false'

  // If ?ticker= is set, first resolve which theme_ids include it
  let filteredThemeIds: string[] | null = null

  if (ticker) {
    const { data: rows } = await supabase
      .from('theme_tickers')
      .select('theme_id')
      .eq('ticker', ticker)

    filteredThemeIds = (rows ?? []).map(r => r.theme_id)
    if (filteredThemeIds.length === 0) {
      return NextResponse.json({ themes: [] })
    }
  }

  // Fetch active themes
  let query = supabase
    .from('themes')
    .select('id, name, timeframe, conviction, momentum, brief, candidate_tickers, expires_at, created_at')
    .eq('is_active', true)
    .order('conviction', { ascending: false })

  if (timeframe && ['1m', '3m', '6m'].includes(timeframe)) {
    query = query.eq('timeframe', timeframe)
  }
  if (filteredThemeIds) {
    query = query.in('id', filteredThemeIds)
  }

  const { data: themes, error: themesErr } = await query

  if (themesErr) {
    return NextResponse.json({ error: themesErr.message }, { status: 500 })
  }
  if (!themes?.length) {
    return NextResponse.json({ themes: [] })
  }

  if (!withWeights) {
    return NextResponse.json({ themes })
  }

  // Enrich each theme with its ticker weights
  const themeIds = themes.map(t => t.id)

  const { data: tickerRows } = await supabase
    .from('theme_tickers')
    .select('theme_id, ticker, weight, rationale')
    .in('theme_id', themeIds)
    .order('weight', { ascending: false })

  // Group by theme_id
  const byTheme = new Map<string, typeof tickerRows>()
  for (const row of tickerRows ?? []) {
    if (!byTheme.has(row.theme_id)) byTheme.set(row.theme_id, [])
    byTheme.get(row.theme_id)!.push(row)
  }

  const enriched = themes.map(t => ({
    ...t,
    tickers: (byTheme.get(t.id) ?? []).map(row => ({
      ticker:    row.ticker,
      weight:    row.weight,
      rationale: row.rationale,
    })),
  }))

  return NextResponse.json({ themes: enriched })
}
