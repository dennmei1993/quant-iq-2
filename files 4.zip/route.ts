/**
 * app/api/cron/themes/route.ts
 *
 * Daily cron — runs 9am UTC.
 *
 * For each timeframe (1m, 3m, 6m):
 *  1. Deactivate existing active theme for that timeframe
 *  2. Call generateTheme() — returns ticker_weights[] with weight + rationale
 *  3. Insert new theme row (candidate_tickers[] for backward compat)
 *  4. Insert theme_tickers rows — one per ticker with AI-assigned weight
 *
 * Auth: CRON_SECRET bearer token
 */

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { generateTheme, type TickerWeight } from '@/lib/ai'

function isAuthorised(req: NextRequest): boolean {
  const auth   = req.headers.get('authorization') ?? ''
  const secret = process.env.CRON_SECRET ?? ''
  return secret.length > 0 && auth === `Bearer ${secret}`
}

const EXPIRY_HOURS: Record<string, number> = {
  '1m': 24,
  '3m': 72,
  '6m': 168,
}

export async function GET(req: NextRequest) {
  if (!isAuthorised(req)) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  const supabase = createServiceClient()
  const log: string[] = []
  const errors: string[] = []

  // Load recent high/medium impact events (last 48h)
  const since = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()

  const { data: events, error: eventsErr } = await supabase
    .from('events')
    .select('id, headline, ai_summary, event_type, sectors, sentiment_score, impact_level, published_at')
    .eq('ai_processed', true)
    .in('impact_level', ['high', 'medium'])
    .gte('published_at', since)
    .order('published_at', { ascending: false })
    .limit(60)

  if (eventsErr) {
    return NextResponse.json({ error: `Failed to fetch events: ${eventsErr.message}` }, { status: 500 })
  }

  if (!events?.length) {
    return NextResponse.json({ status: 'ok', log: ['No recent events — skipping'] })
  }

  log.push(`Using ${events.length} events for theme generation`)

  for (const tf of ['1m', '3m', '6m'] as const) {
    log.push(`--- ${tf} ---`)
    try {
      // 1. Deactivate existing themes for this timeframe
      await supabase
        .from('themes')
        .update({ is_active: false })
        .eq('timeframe', tf)
        .eq('is_active', true)

      // 2. Generate theme with AI-assigned ticker weights
      const theme = await generateTheme(events, tf)

      log.push(`"${theme.name}" — conviction ${theme.conviction}, ${theme.ticker_weights.length} tickers`)

      // 3. Insert theme row
      const { data: newTheme, error: insertErr } = await supabase
        .from('themes')
        .insert({
          name:              theme.name,
          timeframe:         tf,
          conviction:        theme.conviction,
          momentum:          theme.momentum,
          brief:             theme.brief,
          candidate_tickers: theme.candidate_tickers,
          is_active:         true,
          expires_at:        new Date(Date.now() + EXPIRY_HOURS[tf] * 3_600_000).toISOString(),
        })
        .select('id')
        .single()

      if (insertErr || !newTheme) {
        errors.push(`${tf}: theme insert failed — ${insertErr?.message}`)
        continue
      }

      // 4. Sync theme_tickers
      const { inserted, skipped } = await insertThemeTickers(
        supabase, newTheme.id, theme.ticker_weights
      )

      log.push(`${tf}: ${inserted} theme_tickers inserted, ${skipped} skipped (not in assets)`)

    } catch (err) {
      errors.push(`${tf}: ${String(err)}`)
    }
  }

  return NextResponse.json({
    status: errors.length === 0 ? 'ok' : 'partial',
    log,
    errors,
    ts: new Date().toISOString(),
  })
}

// ─── insertThemeTickers ───────────────────────────────────────────────────────

async function insertThemeTickers(
  supabase: ReturnType<typeof createServiceClient>,
  themeId: string,
  tickerWeights: TickerWeight[]
): Promise<{ inserted: number; skipped: number }> {
  if (!tickerWeights.length) return { inserted: 0, skipped: 0 }

  // Validate tickers against assets table to avoid FK violations
  const tickers = tickerWeights.map(tw => tw.ticker)

  const { data: validAssets } = await supabase
    .from('assets')
    .select('ticker')
    .in('ticker', tickers)

  const validSet = new Set((validAssets ?? []).map(a => a.ticker))

  const rows = []
  let skipped = 0

  for (const tw of tickerWeights) {
    if (!validSet.has(tw.ticker)) {
      skipped++
      continue
    }
    rows.push({
      theme_id:  themeId,
      ticker:    tw.ticker,
      weight:    Math.max(0, Math.min(1, tw.weight)),
      rationale: tw.rationale || null,
    })
  }

  if (rows.length === 0) return { inserted: 0, skipped }

  const { error } = await supabase
    .from('theme_tickers')
    .upsert(rows, { onConflict: 'theme_id,ticker' })

  if (error) throw new Error(`theme_tickers upsert failed: ${error.message}`)

  return { inserted: rows.length, skipped }
}
