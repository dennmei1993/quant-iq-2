-- ============================================================================
-- supabase/migrations/004_theme_tickers.sql
--
-- theme_tickers junction table — Option C hybrid implementation.
--
-- Weight model (simplified):
--   weight  float4  0.0–1.0   AI-assigned relevance at theme generation time.
--                             1.0 = primary direct play
--                             0.7 = strong secondary exposure
--                             0.4 = thematic / indirect
--                             0.2 = peripheral, monitor only
--
-- Set once by Claude. Never modified by cron or users.
-- A ticker can appear in multiple themes with different weights.
-- ============================================================================

CREATE TABLE IF NOT EXISTS theme_tickers (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),

  theme_id    uuid        NOT NULL REFERENCES themes(id) ON DELETE CASCADE,
  ticker      text        NOT NULL REFERENCES assets(ticker) ON DELETE CASCADE,

  -- AI-assigned relevance: how central is this ticker to the theme
  weight      float4      NOT NULL DEFAULT 1.0
                CHECK (weight >= 0 AND weight <= 1),

  -- Claude's one-sentence explanation of the ticker's connection to the theme
  rationale   text,

  created_at  timestamptz NOT NULL DEFAULT now(),

  UNIQUE (theme_id, ticker)
);

COMMENT ON TABLE theme_tickers IS
  'Junction table: one row per (theme, ticker) pair.
   weight = AI-assigned relevance (0–1). Set once at theme generation, never changed.
   A ticker may appear in multiple themes with different weights.';

COMMENT ON COLUMN theme_tickers.weight IS
  '0.0–1.0 relevance score assigned by Claude.
   1.0 = primary direct play (e.g. NVDA for AI Infrastructure theme)
   0.7 = strong secondary exposure
   0.4 = thematic / indirect tailwind
   0.2 = peripheral mention, low conviction';

COMMENT ON COLUMN theme_tickers.rationale IS
  'One sentence from Claude explaining why this ticker belongs in this theme.
   Example: "NVDA supplies ~40% of hyperscaler GPU spend driving this buildout."';

-- ── Indexes ──────────────────────────────────────────────────────────────────

-- "All tickers for a theme, sorted by weight" — themes page
CREATE INDEX IF NOT EXISTS theme_tickers_theme_idx
  ON theme_tickers (theme_id, weight DESC);

-- "All themes for a ticker, sorted by weight" — screener, portfolio risk
CREATE INDEX IF NOT EXISTS theme_tickers_ticker_idx
  ON theme_tickers (ticker, weight DESC);

-- ── RLS ───────────────────────────────────────────────────────────────────────

ALTER TABLE theme_tickers ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can read (same policy as themes table)
CREATE POLICY "Authenticated users can read theme_tickers"
  ON theme_tickers FOR SELECT
  TO authenticated
  USING (true);

-- Inserts/deletes handled by service role (cron) — bypasses RLS by default.

-- ── Backfill existing themes ──────────────────────────────────────────────────
-- Expands candidate_tickers[] → one row per ticker, weight=1.0 (unknown relevance).
-- Skips tickers not in the assets table to avoid FK violations.
-- Safe to re-run.

INSERT INTO theme_tickers (theme_id, ticker, weight)
SELECT
  t.id,
  unnest(t.candidate_tickers),
  1.0
FROM themes t
WHERE t.candidate_tickers IS NOT NULL
  AND array_length(t.candidate_tickers, 1) > 0
ON CONFLICT (theme_id, ticker) DO NOTHING;

-- Remove any backfilled rows where the ticker isn't in assets
-- (free-text tickers from old AI output that aren't seeded yet)
DELETE FROM theme_tickers tt
WHERE NOT EXISTS (
  SELECT 1 FROM assets a WHERE a.ticker = tt.ticker
);

-- ── Verify ────────────────────────────────────────────────────────────────────
-- SELECT t.name, t.timeframe, tt.ticker, tt.weight
-- FROM theme_tickers tt
-- JOIN themes t ON t.id = tt.theme_id
-- ORDER BY t.timeframe, tt.weight DESC;
